# Vappa Medicine Tracker — Android v1.6

Offline Android medicine-inventory app, ready for ZIP-only GitHub Actions builds.

## v1.6 interface and usability update

- Premium crimson-to-red gradient **only in the header and primary action buttons**; normal text is charcoal, cards use light neutral surfaces.
- Consistent **stock state colours** and labels: green (enough through next visit), amber (purchase required for upcoming visit), red (seven days or fewer, including zero-stock), grey (no daily dose scheduled).
- Compact dashboard with separate Medicine, Low stock, and To buy counters. Tap **To buy** or **View medicines to purchase** for an expandable shopping list. Sharing through Android's share sheet is included.
- Improved medicine cards prioritize total available stock, approximate days left and an accessible text status; tap **View details** for exact quantities, box breakdown, daily dose, and next-visit calculation. Use explicit **Edit** action instead of silently editing by tapping anywhere.
- Default sorting by urgency, with A–Z and stock-days options; medicine search is retained.
- Three-dot menu divided into Inventory, Patients & Data and Preferences, with menu descriptions.
- Tappable patient profile in header, prominent and editable next-visit card, and contextual empty-list actions.
- Add / Transfer Stock has a full-height entry panel, scrollable selectors, built-in arithmetic keypad (+, −, ×, ÷, =), and a fixed **Save stock change** control, plus confirmation and an Undo action.
- Stock history is displayed as separate readable entries rather than a single block of text.
- Wording polished: no negative zero purchase quantities, no `day(s)` or excessively precise days in summary cards.
- **Medicine photo identification is removed**, including menu controls and JSON export. Photo fields in old databases are ignored, and old JSON backups containing optional photo fields can still be restored (photo data is discarded).
- Safer JSON preview validates the entire incoming medicine list and stock history **before** presenting the destructive restore confirmation.

## Existing behaviour preserved

- Fractional daily requirements such as 0.5 or 0.7 and daily stock reconciliation (Box 1 then Backup). Purchase quantities round **up to whole tablets**.
- Maximum one group of seven-day low-stock alerts per day at 9:00 AM **Asia/Kolkata**, subject to Android's alarm/battery scheduling limitations. Opening the app does not send an additional alert.
- Independent offline patient profiles. Default profile retains the original `vappa_medicines.db` database, and new installs begin with **no medicines and no predefined hospital date**.
- JSON backup / restore per currently selected patient; CSV import / export; purchase list sharing; stock transaction history and Undo.
- No stock-adjustment reasons, expiry date tracking, dark mode, or photography feature.

## GitHub on an Android phone: update just the ZIP

Keep the archive uploaded at the root of the repository with the **exact filename**:

`Vappa_Medicine_Tracker_Android_GitHub.zip`

Keep your existing `.github/workflows/build-apk.yml` file **directly in the repository**. The workflow must unzip the archive before it runs Gradle. This ZIP also includes the workflow for people who upload the extracted project files, but putting the workflow *inside* a ZIP alone cannot trigger GitHub Actions.

1. Replace the existing ZIP in GitHub and commit.
2. Open **Actions → Build Android APK**.
3. If needed select **Run workflow**; successful builds also run automatically on commits to `main`/`master`.
4. Download the `VappaMedicineTracker-debug-apk` artifact, extract it and install `app-debug.apk`.

The workflow uses Gradle 8.9, Java 17, Android Gradle Plugin 8.7.3, compile SDK 35, minimum Android 8 / API 26, and targets SDK 34.

## Backups and safety

**Before updating the APK**, export a separate JSON backup for every patient. GitHub-hosted debug APK signatures can change between builds, which may prevent an in-place install. Do not uninstall the old app until you have copied your backups outside the app.

Restore replaces the **current patient** only; a JSON backup from a patient is not a complete export of all profiles. Older `vappa-medicine-backup-v1` files, including the provided initial nine-medicine JSON and 3 December 2026 visit date, remain supported. Backup source stock snapshots may be reconciled forward by elapsed days; check against physical stock.

Automatic daily deduction is estimated consumption and does **not** confirm that tablets were actually taken. Follow the prescribed dosing schedule; manually correct physical stock as needed.

## Verification

Static project checks, source structure, and ZIP integrity checks performed. An Android SDK/Gradle installation is not available in this environment, so the APK itself **has not been compiled or device-tested here**. Use the GitHub workflow for the compile verification and report any build errors.
