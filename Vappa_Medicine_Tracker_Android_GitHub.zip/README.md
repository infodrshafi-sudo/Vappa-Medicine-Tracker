# Vappa Medicine Tracker — Android app

A native, offline Android medicine-inventory app. **New installations start with zero medicines.** The original Excel inventory is supplied separately as `Vappa_Medicine_Initial_Data.json` for optional manual restoration.

## Features

- Empty medicine list on new installations. Add medicines manually or restore the separate Excel-snapshot JSON.
- Change next hospital visit date; show days left and quantities to purchase.
- Add, edit, and delete medicines; edit tablet requirements and both stock columns.
- **+ Stock**: purchase tablets into Box 1 or Box 2, or transfer tablets from Box 2 to Box 1. Transfers cannot exceed available backup stock.
- Top-left three-dot menu: Settings, Medicine list, Purchase list, Stock history, Excel-compatible CSV export/import, full **JSON** data backup/restore. JSON backup includes medicine quantities, last daily deduction dates, next visit, and history.
- Purchase summary and latest 100 purchase/transfer records, accessed through the menu (not the home screen).
- Standard Android status bar spacing prevents the app header from overlapping notifications and system icons.
- Once-per-local-calendar-day stock deduction (Box 1 first, then Box 2). If the phone was off, missed days are reconciled when the app launches or a receiver runs.
- Low-stock notification if total remaining stock is **7 days or less** at current daily rate (requires notification permission on Android 13+).
- All data stored in an on-device SQLite database. No login or internet required for app use.
- Settings includes a confirmation-protected **Clear all medicines and stock history** action for existing installations.

## Build APK on GitHub (no coding needed)

1. Create a **new, empty GitHub repository** (do not add a README during creation).
2. **Unzip** this project, then upload the **contents of the `VappaMedicineTracker` folder** into the repository. In particular, preserve `.github/workflows/build-apk.yml` (hidden folder). If uploading by Android phone, use GitHub's **Add file → Upload files** in desktop mode, or a GitHub mobile-compatible Git client for full folder upload.
3. Commit uploaded files to the `main` branch.
4. In GitHub open **Actions → Build Android APK → Run workflow** (or the push build will run automatically).
5. Once the green build completes, open that run → **Artifacts** → `VappaMedicineTracker-debug-apk`.
6. Download and extract the artifact ZIP. Install `app-debug.apk` on your Android phone. You may need to allow installation from the browser or file manager.

**Important:** GitHub generates a debug-signed APK, suitable for personal testing. For Play Store release or stable long-term updates, set up your own production signing key. Future debug APKs from the same build configuration may not be installable as updates if GitHub's signing key changes; back up your data before uninstalling. Use **⋮ → Backup data** to export a JSON backup before uninstalling or clearing app data. **⋮ → Restore data** restores the medicine list, visit date and stock history. Excel options use **CSV** files (not native XLSX).

## Stock and scheduling rules

- Today's quantities are treated as the stock available on the day first opened/edited. The first automatic deduction happens after the **next local midnight**, normally during the scheduled alarm at **00:05** (delivery can be delayed by Android power-saving settings).
- Every missed calendar date is deducted just once, so delayed background alarms or offline days don't double-deduct.
- Expected daily consumption is used; it does **not** prove a medicine was taken. Use **Edit medicine** to reconcile actual stock as needed.
- Fractional daily rates (e.g. 0.7) are supported for inventory planning; these do not specify the prescribed dose. Use prescribed medical instructions for actual administration.
- Purchase quantity = ceil(max(0, days until next visit × daily requirement − Box 1 − Box 2)).
- Warning appears when total stock / daily rate <= 7 days; inactive (0/day) medicines do not alert.
- The separately supplied JSON is an Excel snapshot, not verified medical prescribing advice. **Ticagrelor** is normalized from the sheet's spelling `ticagrelo`. Validate medicine names, dosing, and quantities before use. The snapshot is dated **2026-11-01**, so restore on a later day will automatically reconcile expected consumption since that date. To instead treat the saved quantities as current, update the JSON `last_date` fields to the stock count date before restoring.

## Project details

- Package: `com.vappa.medicinetracker`
- Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, Android compile SDK 35
- Minimum Android version: 8.0 (API 26)
- No third-party SDKs, advertising, analytics or network requests.

## Open in Android Studio

Open the folder containing `settings.gradle`, sync Gradle, and select **Build → Build APK(s)**.

## Limitations

- Android may delay background execution, so the app uses a best-effort midnight alarm and catches up reliably when opened. Do not rely on it as a dose-taking alarm.
- Changing the device clock/timezone can affect the calculated daily stock. Verify quantities if the clock changes.
- The automatic calculation is for medicine availability planning, not a medication adherence record.

## Android phone GitHub ZIP-only upload

If GitHub mobile does not allow folder uploads, upload the entire `Vappa_Medicine_Tracker_Android_GitHub.zip` to the repository root, and create `.github/workflows/build-apk.yml` manually in GitHub using the separate `GITHUB_ZIP_ONLY_WORKFLOW.yml` file supplied alongside the ZIP. The workflow extracts the project and builds the debug APK. Do not upload the ZIP inside another folder.

## Empty app + original inventory JSON (v1.2)

The APK **does not pre-populate medicines** on a fresh installation. Download `Vappa_Medicine_Initial_Data.json` separately and use **\u22ee → Restore data** to load the original nine medicines and the next visit date. The menu also offers **Backup data**, which saves a JSON file in the same compatible format.

**Updating an existing installation does not erase its local database.** To make an existing installation empty, first export a backup, then open **\u22ee → Settings → Clear all medicines and stock history** and confirm. No other data is silently erased during installation.

For GitHub mobile **ZIP-only** upload, keep exactly the name `Vappa_Medicine_Tracker_Android_GitHub.zip` in the repository root. Keep using the previously created ZIP-extraction GitHub workflow; it should run `unzip -o Vappa_Medicine_Tracker_Android_GitHub.zip` before Gradle. Do **not** upload the JSON inventory file to a public GitHub repository: keep it on the phone and restore from the app.
