# Vappa Medicine Tracker — Android app (v1.4)

An offline Android medicine-inventory application. New installations start with an **empty medicine list and no preselected hospital visit date**. Original medicines and the 3 December 2026 visit are available separately in `Vappa_Medicine_Initial_Data.json` for manual restoration.

## What is new

- Multiple independent patient profiles, switchable from the **⋮** menu. The existing Vappa database remains the default profile during an upgrade. Each patient's stock, hospital visit, and history are separate.
- Medicines can be searched and sorted A–Z, by urgency, or by days of available stock.
- Purchase requirements calculate from daily consumption × days to next visit minus combined stock. **Fractional daily requirements are retained**; quantities to purchase are rounded **up** to full tablets.
- Purchase list expands when tapped on the home dashboard and can also be opened from **⋮ → Purchase list**. The purchase dialog has **Share with pharmacy** (Android share sheet / WhatsApp / messages).
- Purchase and backup-to-Box-1 transfer support; **Undo latest purchase / transfer** in Settings reverses a transaction only if sufficient stock is still available. No reasons are required for direct manual inventory edits.
- Optional medicine identification photo: tap medicine → **Photo / Delete → Add or change identification photo**. Photos are resized and saved in the local database, and included in patient-level JSON exports.
- JSON backup and restore, including a **preview** of visit date, medicine list and stock/history record counts. Restore validates data before replacement and requires confirmation. An optional patient label identifies the source, but importing only replaces the currently selected patient's data.
- One grouped low-stock alert per day at **9 AM IST**, if at least one active medicine has seven or fewer days' available stock. This is a best-effort Android alarm; battery optimization may delay it. The alarm also reconciles missed daily deductions; the app always catches up on reopen. **Opening the app does not trigger an extra notification.**
- Removed hardcoded visit date. Set it manually or restore a JSON containing it.
- No expiry tracking, dark mode, or stock adjustment reason prompts.

## GitHub mobile: replace only one ZIP

The repository can keep a single file named exactly `Vappa_Medicine_Tracker_Android_GitHub.zip` at its root. Retain your existing `.github/workflows/build-apk.yml` GitHub Actions file (created once in the repository). It must extract the ZIP before running Gradle:

```yaml
name: Build Android APK
on:
  workflow_dispatch:
  push:
    branches: [main, master]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Extract project ZIP
        run: unzip -o Vappa_Medicine_Tracker_Android_GitHub.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Build APK
        run: gradle --no-daemon assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: Vappa-Medicine-Tracker-APK
          path: app/build/outputs/apk/debug/app-debug.apk
```

Once the workflow is in place, replacing that ZIP in GitHub and committing is sufficient. If the upload is called a different filename, the workflow will fail.

**Note:** The ZIP also includes `.github/workflows/build-apk.yml` for developers who choose to extract the project into a repository. The workflow inside the ZIP is not activated automatically by uploading the ZIP: GitHub only runs workflow files already present directly in the repository.

## Backups and update safety

- JSON backups are per active patient and preserve `format: vappa-medicine-backup-v1` for compatibility with the initial Excel JSON. A backup is **not** a complete multi-patient export; back up each patient separately.
- A fresh installation starts empty; APK updates of this same application ID keep existing patient data.
- Photo content is embedded in JSON backup and may make backups large.
- Initial backup values are an inventory snapshot as of **2026-11-01**. Restoring later causes the app to estimate the expected stock consumption between the snapshot day and the restore day. Verify physical stock and follow actual prescriptions.
- Updating debug APKs built by different GitHub runners may fail due to debug signing differences. **Back up every patient before uninstalling or clearing data.**

## Android components

Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35, minimum Android 8 (API 26), target SDK 34. No network permission or account required. All patient records are local SQLite databases. Android scheduling is inexact and depends on OS power policies.

## Verification status

Source structure and ZIP integrity checked. Android APK compilation and device notifications **have not been verified** in this environment; run the GitHub workflow and test on your phone. This is an inventory planning app, not a clinical dosing or actual dose-adherence record.


## Version 1.5 (red-gradient UI and stock calculator)
- Crimson-to-rose gradient app header and primary action buttons; softer red summary card; neutral medicine cards.
- Built-in arithmetic keypad on Add / Transfer Stock quantity: +, minus, multiply, divide, decimals, clear, backspace, equals. Standard operator precedence; validates positive quantity before saving.
- Does not change stored data or the 9 AM IST low-stock reminder behavior.
