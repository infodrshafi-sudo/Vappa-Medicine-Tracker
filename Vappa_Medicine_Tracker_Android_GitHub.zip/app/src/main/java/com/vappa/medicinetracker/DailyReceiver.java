package com.vappa.medicinetracker;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.time.*;
import java.util.*;

public class DailyReceiver extends BroadcastReceiver {
  public static final String CHANNEL="vappa_stock";
  private static final String ALERT_PREFS="vappa_stock_notifications";
  private static final String LAST_ALERT_DAY="last_low_stock_notification_day_ist";
  private static final ZoneId INDIA=ZoneId.of("Asia/Kolkata");
  @Override public void onReceive(Context context,Intent intent){
    // Reconcile every patient; reminders are sent only by this scheduled 9 AM broadcast.
    String profiles=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("profiles","[{\"id\":\"default\",\"name\":\"Vappa\"}]");
    try{org.json.JSONArray a=new org.json.JSONArray(profiles);for(int k=0;k<a.length();k++){String id=a.getJSONObject(k).optString("id","default");MedicineDb d=new MedicineDb(context,id);d.reconcile();d.close();}}catch(Exception ignored){MedicineDb d=new MedicineDb(context);d.reconcile();d.close();}
    notifyLow(context);schedule(context);
  }
  public static void schedule(Context context){
    AlarmManager mgr=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
    if(mgr==null)return;
    Intent intent=new Intent(context,DailyReceiver.class);
    PendingIntent pi=PendingIntent.getBroadcast(context,404,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    ZonedDateTime now=ZonedDateTime.now(INDIA);
    ZonedDateTime next=now.toLocalDate().atTime(9,0).atZone(INDIA);
    if(!next.isAfter(now))next=next.plusDays(1);
    mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),pi);
  }
  public static void notifyLow(Context c){
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    if(nm==null)return;
    if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL,"Medicine stock alerts",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("Daily 9 AM IST alert when 7 days or less of medicine remain");nm.createNotificationChannel(channel);}
    if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
    String today=LocalDate.now(INDIA).toString();
    android.content.SharedPreferences prefs=c.getSharedPreferences(ALERT_PREFS,Context.MODE_PRIVATE);
    if(today.equals(prefs.getString(LAST_ALERT_DAY,"")))return;
    ArrayList<String> low=new ArrayList<>();
    String profiles=c.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("profiles","[{\"id\":\"default\",\"name\":\"Vappa\"}]");
    try{org.json.JSONArray a=new org.json.JSONArray(profiles);for(int k=0;k<a.length();k++){org.json.JSONObject o=a.getJSONObject(k);MedicineDb db=new MedicineDb(c,o.optString("id","default"));for(MedicineDb.Medicine m:db.all())if(m.daily>0&&m.daysLeft()<=7)low.add(o.optString("name","Patient")+": "+m.name);db.close();}}catch(Exception ignored){}
    if(low.isEmpty())return;
    Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,403,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    String desc=String.join(", ",low);
    Notification notification=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Medicine stock: "+low.size()+" reorder alert(s)").setContentText(desc).setStyle(new Notification.BigTextStyle().bigText("7 days or less remaining: "+desc)).setContentIntent(pi).setAutoCancel(true).build();
    nm.notify(42,notification);prefs.edit().putString(LAST_ALERT_DAY,today).apply();
  }
}
