package com.vappa.medicinetracker;

import android.app.*;
import android.content.*;
import android.os.Build;
import java.time.*;
import java.util.*;

public class DailyReceiver extends android.content.BroadcastReceiver {
  public static final String CHANNEL="vappa_stock";
  @Override public void onReceive(Context context,Intent intent){MedicineDb db=new MedicineDb(context);db.reconcile();notifyLow(context,db);schedule(context);db.close();}
  public static void schedule(Context context){
    AlarmManager mgr=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
    Intent i=new Intent(context,DailyReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(context,404,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    ZonedDateTime now=ZonedDateTime.now();ZonedDateTime next=now.toLocalDate().plusDays(1).atTime(0,5).atZone(now.getZone());
    // Inexact alarm avoids special exact-alarm access; Android battery restrictions can delay execution.
    mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.toInstant().toEpochMilli(),pi);
  }
  public static void notifyLow(Context c,MedicineDb db){
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL,"Medicine stock alerts",NotificationManager.IMPORTANCE_HIGH);channel.setDescription("Warnings when seven days or fewer of tablets remain");nm.createNotificationChannel(channel);}
    ArrayList<String> low=new ArrayList<>();for(MedicineDb.Medicine m:db.all())if(m.daily>0 && m.daysLeft()<=7)low.add(m.name);
    if(low.isEmpty()){nm.cancel(42);return;}
    if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
    Intent open=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,403,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    String desc=String.join(", ",low);
    Notification notification=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Reorder medicine: "+low.size()+" low-stock item(s)").setContentText(desc).setStyle(new Notification.BigTextStyle().bigText("7 days or less remaining: "+desc)).setContentIntent(pi).setAutoCancel(true).build();nm.notify(42,notification);
  }
}
