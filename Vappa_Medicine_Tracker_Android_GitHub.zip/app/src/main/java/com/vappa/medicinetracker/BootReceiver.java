package com.vappa.medicinetracker;
import android.content.*;
public class BootReceiver extends android.content.BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i){DailyReceiver.schedule(c);}
}
