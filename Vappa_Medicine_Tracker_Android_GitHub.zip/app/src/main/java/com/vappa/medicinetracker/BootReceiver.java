package com.vappa.medicinetracker;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){MedicineDb db=new MedicineDb(c);db.reconcile();DailyReceiver.schedule(c);DailyReceiver.notifyLow(c,db);db.close();}
}
