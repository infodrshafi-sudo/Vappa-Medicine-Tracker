package com.vappa.medicinetracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.io.*;
import android.net.Uri;
import android.provider.OpenableColumns;

public class MainActivity extends Activity {
  private MedicineDb db; private LinearLayout root,items; private String activeProfile="default",searchTerm="";private int sortMode=0;private static final int PHOTO_PICK=505;private long photoMedicineId=-1; private static final int EXPORT_CSV=501, IMPORT_CSV=502, BACKUP=503, RESTORE=504; private TextView summary,visitText; private LinearLayout purchaseExpansion; private boolean purchaseExpanded=false; private final int teal=Color.rgb(14,112,119),ink=Color.rgb(32,48,57),muted=Color.rgb(100,117,125),red=Color.rgb(174,48,48);
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(teal);getWindow().setNavigationBarColor(Color.rgb(245,248,249));getWindow().getDecorView().setSystemUiVisibility(0);activeProfile=getPreferences(MODE_PRIVATE).getString("active_profile","default");db=new MedicineDb(this,activeProfile);db.reconcile();DailyReceiver.schedule(this);if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);draw();}
  @Override protected void onResume(){super.onResume();if(db!=null){db.reconcile();if(root!=null)draw();}}
  @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
  private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+0.5f);}
  private GradientDrawable bg(int fill,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));return d;}
  private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
  private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private void pad(View v,int p){v.setPadding(dp(p),dp(p),dp(p),dp(p));}
  private void space(LinearLayout l,int h){View x=new View(this);l.addView(x,new LinearLayout.LayoutParams(1,dp(h)));}
  private TextView button(String name,Runnable action){TextView t=label(name,14,Color.WHITE,true);t.setGravity(Gravity.CENTER);pad(t,12);t.setBackground(bg(teal,12));t.setOnClickListener(v->action.run());return t;}
  private String fmt(double x){if(Math.abs(x-Math.rint(x))<0.00001)return String.format(Locale.US,"%.0f",x);return String.format(Locale.US,"%.2f",x).replaceAll("0+$","").replaceAll("\\.$","");}
  private void draw(){
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(245,248,249));root=column();pad(root,16);scroll.addView(root);setContentView(scroll);
    LinearLayout toolbar=row();toolbar.setGravity(Gravity.CENTER_VERTICAL);TextView menu=label("⋮",30,teal,true);menu.setGravity(Gravity.CENTER);menu.setContentDescription("Open app menu");menu.setBackground(bg(Color.rgb(226,244,242),12));toolbar.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(48)));LinearLayout head=column();TextView title=label("Vappa Medicine Tracker",21,teal,true);head.addView(title);head.addView(label("Profile: "+profileLabel()+" • Offline",12,muted,false));LinearLayout.LayoutParams hparams=new LinearLayout.LayoutParams(0,-2,1);hparams.leftMargin=dp(10);toolbar.addView(head,hparams);menu.setOnClickListener(v->showMenu(menu));root.addView(toolbar);space(root,18);
    LinearLayout visit=row();pad(visit,15);visit.setBackground(bg(Color.WHITE,16));LinearLayout info=column();visitText=label("Next visit: "+getVisitLabel(),16,ink,true);info.addView(visitText);info.addView(label(db.daysToVisit()+" day(s) remaining • Tap to change",12,muted,false));visit.addView(info,new LinearLayout.LayoutParams(0,-2,1));visit.addView(label("✎",22,teal,true));visit.setOnClickListener(v->dateDialog());root.addView(visit);space(root,12);
    LinearLayout stats=column();pad(stats,16);stats.setBackground(bg(Color.rgb(226,244,242),16));summary=label("",15,ink,true);summary.setGravity(Gravity.CENTER_VERTICAL);summary.setMinHeight(dp(44));
    summary.setContentDescription("Show or hide purchase list");summary.setOnClickListener(v->{purchaseExpanded=!purchaseExpanded;refreshCards();});
    stats.addView(summary);purchaseExpansion=column();stats.addView(purchaseExpansion);root.addView(stats);space(root,12);
    LinearLayout actions=row();TextView stock=button("+ Stock",()->stockDialog());actions.addView(stock,new LinearLayout.LayoutParams(0,dp(50),1));TextView add=button("+ Medicine",()->editDialog(null));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(50),1);ap.leftMargin=dp(8);actions.addView(add,ap);root.addView(actions);space(root,10);
    space(root,20);
    root.addView(label("MY MEDICINES",13,muted,true));space(root,8);
    LinearLayout filters=row();EditText search=field("Search medicines",searchTerm,false);search.setSingleLine(true);
    filters.addView(search,new LinearLayout.LayoutParams(0,dp(52),1));
    Spinner order=new Spinner(this);order.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"A–Z","Urgency","Stock days"}));order.setSelection(sortMode);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(120),dp(52));op.leftMargin=dp(7);filters.addView(order,op);root.addView(filters);
    search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence c,int st,int count,int after){}public void onTextChanged(CharSequence c,int st,int before,int count){searchTerm=c.toString();refreshCards();}public void afterTextChanged(Editable e){}});
    order.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int position,long id){sortMode=position;refreshCards();}public void onNothingSelected(android.widget.AdapterView<?> a){}});
    items=column();root.addView(items);refreshCards();space(root,16);root.addView(label("Stock decreases once per elapsed day, at the daily requirement. Box 1 is used first, then backup. Records can be corrected manually if actual consumption differs.",12,muted,false));
  }
  private void showMenu(View anchor){
    PopupMenu p=new PopupMenu(this,anchor);String[] options={"Settings","Switch / add patient","Medicine list","Purchase list","Stock history","Export to Excel (CSV)","Import from Excel (CSV)","Backup data","Restore data"};
    for(int i=0;i<options.length;i++)p.getMenu().add(0,i, i,options[i]);
    p.setOnMenuItemClickListener(item->{switch(item.getItemId()){
      case 0:settingsDialog();break;
      case 1:profileDialog();break;
      case 2:medicineListDialog();break;
      case 3:purchaseDialog();break;
      case 4:historyDialog();break;
      case 5:documentPicker(Intent.ACTION_CREATE_DOCUMENT,"text/csv","Vappa_Medicines.csv",EXPORT_CSV);break;
      case 6:documentPicker(Intent.ACTION_OPEN_DOCUMENT,"text/*",null,IMPORT_CSV);break;
      case 7:documentPicker(Intent.ACTION_CREATE_DOCUMENT,"application/json","Vappa_Medicine_Backup.json",BACKUP);break;
      case 8:documentPicker(Intent.ACTION_OPEN_DOCUMENT,"application/json",null,RESTORE);break;
    }return true;});p.show();
  }
  private void settingsDialog(){
    LinearLayout c=column();pad(c,18);c.addView(label("Next hospital visit: "+getVisitLabel(),16,ink,true));space(c,9);c.addView(label("Low-stock notifications: once daily at 9:00 AM India time, only if stock is 7 days or less. Android may delay notifications.",14,muted,false));space(c,9);c.addView(label("Daily stock is automatically reconciled once per elapsed calendar day, using Box 1 first and then backup. If a dose was missed, edit the physical stock to correct it.",14,muted,false));space(c,12);
    TextView change=button("Change next visit",()->dateDialog());c.addView(change);space(c,10);
    TextView clear=button("Clear all medicines and stock history",()->new AlertDialog.Builder(this)
      .setTitle("Clear medicine inventory?")
      .setMessage("This permanently deletes medicines and stock history on this phone. Your visit date stays unchanged. Please make a JSON backup first if you want to keep your records.")
      .setNegativeButton("Cancel",null)
      .setPositiveButton("Clear inventory",(d,w)->{db.clearInventory();draw();message("Inventory cleared","You can now use \u22ee > Restore data to import your medicine JSON, or add medicines individually.");}).show());
    c.addView(clear);space(c,10);
    TextView undo=button("Undo latest purchase / transfer",()->new AlertDialog.Builder(this).setTitle("Undo last transaction?").setMessage("Reverses the latest purchase or transfer if sufficient stock is still available. It does not undo daily consumption.").setNegativeButton("Cancel",null).setPositiveButton("Undo",(d,w)->{String err=db.undoLatest();if(err==null){draw();message("Undone","The stock change has been reversed.");}else error(err);}).show());c.addView(undo);
    new AlertDialog.Builder(this).setTitle("Settings").setView(c).setPositiveButton("Close",null).show();
  }
  private void medicineListDialog(){
    String[] names=new String[db.all().size()+1];names[0]="+ Add new medicine";int i=1;for(MedicineDb.Medicine m:db.all())names[i++]=m.name;
    new AlertDialog.Builder(this).setTitle("Medicine list • tap to edit").setItems(names,(d,idx)->{if(idx==0)editDialog(null);else editDialog(db.all().get(idx-1));}).setNegativeButton("Close",null).show();
  }
  private void documentPicker(String action,String mime,String filename,int request){
    Intent i=new Intent(action);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);if(filename!=null)i.putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,request);
  }
  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
    Uri uri=data.getData();
    try{
      if(request==PHOTO_PICK){try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("Cannot read photo");Bitmap original=BitmapFactory.decodeStream(in);if(original==null)throw new IOException("Invalid image");int max=700;float ratio=Math.min(1f,Math.min((float)max/original.getWidth(),(float)max/original.getHeight()));Bitmap scaled=Bitmap.createScaledBitmap(original,Math.max(1,Math.round(original.getWidth()*ratio)),Math.max(1,Math.round(original.getHeight()*ratio)),true);ByteArrayOutputStream out=new ByteArrayOutputStream();scaled.compress(Bitmap.CompressFormat.JPEG,65,out);if(out.size()>900000)throw new IOException("Image too large");db.updatePhoto(photoMedicineId,Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));draw();message("Photo saved","Identification photo is included in JSON backups.");}return;}
      if(request==EXPORT_CSV||request==BACKUP){String value=request==EXPORT_CSV?db.exportCsv():db.exportBackup();if(request==BACKUP){org.json.JSONObject backupJson=new org.json.JSONObject(value);backupJson.put("patient",profileLabel());value=backupJson.toString(2);}try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("Cannot open selected file");out.write(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));}message("Saved successfully",request==BACKUP?"Keep this backup file in a safe location.":"Open this CSV file in Microsoft Excel or Google Sheets.");}
      else if(request==IMPORT_CSV||request==RESTORE){String value;try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("Cannot read selected file");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>20_000_000)throw new IOException("File exceeds 20 MB");}value=out.toString("UTF-8");}
        final String content=value;
        new AlertDialog.Builder(this).setTitle(request==RESTORE?"Preview JSON restore":"Import Excel CSV?").setMessage(request==RESTORE?restorePreview(content):"This will REPLACE the current medicine list with medicines in the CSV file. Export a backup first.").setNegativeButton("Cancel",null).setPositiveButton("Continue",(d,w)->{try{if(request==RESTORE)db.restoreBackup(content);else db.importCsv(content);db.reconcile();draw();message("Successful",request==RESTORE?"Backup restored.":"Medicine list imported.");}catch(Exception e){error("Could not read file: "+e.getMessage());}}).show();
      }
    }catch(Exception e){error("File operation failed: "+e.getMessage());}
  }
  private String restorePreview(String content){try{return "Patient in file: "+new org.json.JSONObject(content).optString("patient","Not specified")+"\n"+db.backupPreview(content)+"\nThis will REPLACE the current profile's medicines, visit and stock history. Please back up existing data first.";}catch(Exception e){return "Invalid backup: "+e.getMessage()+"\nRestore will be blocked if invalid.";}}
  private void message(String title,String body){new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK",null).show();}
  private String getVisitLabel(){if(db.getVisit().isEmpty())return "Not set (tap to choose)";try{return LocalDate.parse(db.getVisit()).format(DateTimeFormatter.ofPattern("d MMM yyyy",Locale.ENGLISH));}catch(Exception e){return db.getVisit();}}
  private void refreshCards(){items.removeAllViews();int alert=0,needed=0;long days=db.daysToVisit();List<MedicineDb.Medicine> meds=db.all();if(meds.isEmpty()){TextView empty=label("No medicines added yet. Tap + Medicine or choose \u22ee > Restore data to import a JSON backup.",15,muted,false);pad(empty,14);empty.setBackground(bg(Color.WHITE,14));items.addView(empty);}for(MedicineDb.Medicine m:meds){if(m.daily>0&&m.daysLeft()<=7)alert++;if(m.daily*days>m.total()+0.00001)needed++;}
    List<MedicineDb.Medicine> displayed=new ArrayList<>(meds);displayed.removeIf(m->!m.name.toLowerCase(Locale.ROOT).contains(searchTerm.toLowerCase(Locale.ROOT)));
    if(sortMode==1)Collections.sort(displayed,(a,b)->{boolean ar=a.daily>0&&a.daysLeft()<=7,br=b.daily>0&&b.daysLeft()<=7;if(ar!=br)return ar?-1:1;boolean ap=a.daily*days>a.total(),bp=b.daily*days>b.total();if(ap!=bp)return ap?-1:1;return Double.compare(a.daysLeft(),b.daysLeft());});
    else if(sortMode==2)Collections.sort(displayed,(a,b)->Double.compare(a.daysLeft(),b.daysLeft()));
    for(MedicineDb.Medicine m:displayed)medicineCard(m);summary.setText(meds.size()+" medicines  •  "+alert+" low stock\n"+needed+" need purchase   "+(purchaseExpanded?"▴ Hide list":"▾ Tap to view list"));updatePurchaseExpansion();}
  private void medicineCard(MedicineDb.Medicine m){
    LinearLayout card=column();pad(card,15);card.setBackground(bg(Color.WHITE,15));LinearLayout line=row();TextView name=label(m.name,17,ink,true);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));String status=m.daily<=0?"NOT SCHEDULED":m.daysLeft()<=7?"REORDER":"IN STOCK";int c=m.daily>0&&m.daysLeft()<=7?red:teal;line.addView(label(status,11,c,true));card.addView(line);if(m.photo!=null&&!m.photo.isEmpty()){try{byte[] bytes=Base64.decode(m.photo,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bmp!=null){ImageView iv=new ImageView(this);iv.setImageBitmap(bmp);iv.setAdjustViewBounds(true);iv.setMaxHeight(dp(125));card.addView(iv);}}catch(Exception ignored){}}space(card,10);
    card.addView(label("Box 1: "+fmt(m.b1)+"    •    Backup: "+fmt(m.b2)+"    •    Total: "+fmt(m.total()),14,ink,false));space(card,5);
    card.addView(label("Daily: "+fmt(m.daily)+"    •    Stock lasts: "+(m.daily<=0?"Not applicable":fmt(m.daysLeft())+" days"),13,muted,false));
    double buy=Math.max(0,m.daily*db.daysToVisit()-m.total());space(card,5);card.addView(label("Needed until visit: "+fmt(m.daily*db.daysToVisit())+"   •   Buy: "+fmt(Math.ceil(buy-0.0000001)),13,buy>0?red:teal,true));
    card.setOnClickListener(v->editDialog(m));items.addView(card);space(items,9);
  }
  private void dateDialog(){LocalDate d;try{d=LocalDate.parse(db.getVisit());}catch(Exception e){d=LocalDate.now().plusMonths(1);}DatePickerDialog dlg=new DatePickerDialog(this,(picker,y,m,day)->{db.setVisit(LocalDate.of(y,m+1,day).toString());draw();},d.getYear(),d.getMonthValue()-1,d.getDayOfMonth());dlg.setTitle("Next hospital visit");dlg.show();}
  private EditText field(String hint,String initial,boolean number){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);e.setText(initial);if(number)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);return e;}
  private void addField(LinearLayout p,String title,EditText e){p.addView(label(title,13,muted,true));p.addView(e);space(p,7);}
  private Double parseNonnegative(EditText e){try{double n=Double.parseDouble(e.getText().toString().trim());return Double.isFinite(n)&&n>=0?n:null;}catch(Exception ex){return null;}}
  private void error(String msg){new AlertDialog.Builder(this).setTitle("Please check").setMessage(msg).setPositiveButton("OK",null).show();}
  private void editDialog(MedicineDb.Medicine m){
    boolean existing=m!=null;LinearLayout form=column();pad(form,18);EditText name=field("Medicine name",existing?m.name:"",false);EditText daily=field("Daily requirement",existing?fmt(m.daily):"1",true);EditText b1=field("Box 1 tablets",existing?fmt(m.b1):"0",true);EditText b2=field("Backup tablets",existing?fmt(m.b2):"0",true);
    addField(form,"Medicine name",name);addField(form,"Tablets per day (fractional values allowed)",daily);addField(form,"Current use — Box 1",b1);addField(form,"Backup — Box 2",b2);
    AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(existing?"Edit medicine":"Add medicine").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null);
    if(existing)builder.setNeutralButton("Photo / Delete",(dialog,which)->new AlertDialog.Builder(this).setTitle(m.name).setItems(new String[]{"Add or change identification photo","Remove photo","Delete medicine"},(x,which)->{if(which==0){photoMedicineId=m.id;documentPicker(Intent.ACTION_OPEN_DOCUMENT,"image/*",null,PHOTO_PICK);}else if(which==1){db.updatePhoto(m.id,"");draw();}else new AlertDialog.Builder(this).setTitle("Delete "+m.name+"?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.delete(m.id);draw();}).show();}).show());
    AlertDialog dialog=builder.create();dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{String n=name.getText().toString().trim();Double d=parseNonnegative(daily),x=parseNonnegative(b1),y=parseNonnegative(b2);if(n.isEmpty()||d==null||x==null||y==null){error("Enter a medicine name and valid non-negative quantities.");return;}db.upsert(existing?m.id:null,n,d,x,y);dialog.dismiss();draw();}));dialog.show();
  }
  private void stockDialog(){
    List<MedicineDb.Medicine> meds=db.all();if(meds.isEmpty()){error("Add a medicine first.");return;}String[] names=new String[meds.size()];for(int i=0;i<names.length;i++)names[i]=meds.get(i).name;
    LinearLayout form=column();pad(form,18);Spinner med=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);med.setAdapter(adapter);form.addView(label("Medicine",13,muted,true));form.addView(med);space(form,8);
    Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Purchase new stock","Transfer backup → Box 1"}));form.addView(label("Action",13,muted,true));form.addView(type);space(form,8);
    EditText amount=field("Quantity", "",true);addField(form,"Quantity (tablets)",amount);
    Spinner dest=new Spinner(this);dest.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Box 1 (current use)","Box 2 (backup)"}));form.addView(label("Purchase destination",13,muted,true));form.addView(dest);type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){dest.setVisibility(pos==0?View.VISIBLE:View.GONE);}public void onNothingSelected(android.widget.AdapterView<?> p){}});
    AlertDialog dlg=new AlertDialog.Builder(this).setTitle("+ Add / Transfer Stock").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{Double qty=parseNonnegative(amount);if(qty==null||qty<=0){error("Enter a quantity greater than zero.");return;}MedicineDb.Medicine m=meds.get(med.getSelectedItemPosition());boolean transfer=type.getSelectedItemPosition()==1;boolean toBackup=dest.getSelectedItemPosition()==1;String result=db.stockAction(m.id,transfer,toBackup,qty);if(result!=null){error(result);return;}dlg.dismiss();draw();}));dlg.show();
  }
  private void updatePurchaseExpansion(){
    if(summary==null || purchaseExpansion==null)return;
    purchaseExpansion.removeAllViews();
    if(!purchaseExpanded)return;
    space(purchaseExpansion,9);
    View separator=new View(this);separator.setBackgroundColor(Color.rgb(188,218,216));purchaseExpansion.addView(separator,new LinearLayout.LayoutParams(-1,dp(1)));
    space(purchaseExpansion,10);
    purchaseExpansion.addView(label("PURCHASE LIST • UNTIL "+getVisitLabel(),12,muted,true));
    long days=db.daysToVisit();int count=0;
    for(MedicineDb.Medicine m:db.all()){
      double needed=Math.max(0,m.daily*days-m.total());
      if(needed<=0.000001)continue;
      LinearLayout line=row();line.setPadding(0,dp(7),0,dp(7));
      TextView medicine=label(m.name,15,ink,false);line.addView(medicine,new LinearLayout.LayoutParams(0,-2,1));
      TextView qty=label(fmt(Math.ceil(needed-0.000001))+" tablets",15,red,true);line.addView(qty);
      purchaseExpansion.addView(line);count++;
    }
    if(count==0){purchaseExpansion.addView(label("All medicines are adequately stocked until your next visit.",14,teal,false));}
  }
  private String purchaseText(){StringBuilder b=new StringBuilder();long days=db.daysToVisit();for(MedicineDb.Medicine m:db.all()){double n=Math.max(0,m.daily*days-m.total());if(n>0.000001)b.append(m.name).append(": ").append(fmt(Math.ceil(n-0.000001))).append(" tablet(s)\n");}return b.length()==0?"All medicines have enough stock for the next visit.":b.toString().trim();}
  private void purchaseDialog(){String text=purchaseText();new AlertDialog.Builder(this).setTitle("To purchase until "+getVisitLabel()).setMessage(text).setNeutralButton("Share with pharmacy",(d,w)->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"Medicines to purchase (until "+getVisitLabel()+"):\n"+text);startActivity(Intent.createChooser(i,"Share purchase list"));}).setPositiveButton("Done",null).show();}
  private org.json.JSONArray profiles(){try{return new org.json.JSONArray(getPreferences(MODE_PRIVATE).getString("profiles","[{\"id\":\"default\",\"name\":\"Vappa\"}]"));}catch(Exception e){return new org.json.JSONArray();}}
  private String profileLabel(){org.json.JSONArray a=profiles();for(int i=0;i<a.length();i++){org.json.JSONObject o=a.optJSONObject(i);if(o!=null&&activeProfile.equals(o.optString("id")))return o.optString("name","Vappa");}return "Vappa";}
  private void switchProfile(String id){if(db!=null)db.close();activeProfile=id;getPreferences(MODE_PRIVATE).edit().putString("active_profile",id).apply();db=new MedicineDb(this,activeProfile);db.reconcile();searchTerm="";draw();}
  private void profileDialog(){org.json.JSONArray a=profiles();String[] labels=new String[a.length()+1];for(int i=0;i<a.length();i++)labels[i]=a.optJSONObject(i).optString("name")+(activeProfile.equals(a.optJSONObject(i).optString("id"))?"  ✓":"");labels[a.length()]="+ Add patient";
    new AlertDialog.Builder(this).setTitle("Patient profiles").setItems(labels,(d,which)->{if(which<a.length())switchProfile(a.optJSONObject(which).optString("id"));else{EditText input=field("Patient name","",false);new AlertDialog.Builder(this).setTitle("New patient profile").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Add",(dialog,w)->{String name=input.getText().toString().trim();if(name.isEmpty()){error("Enter patient name");return;}try{org.json.JSONObject o=new org.json.JSONObject();o.put("name",name);o.put("id","p"+java.util.UUID.randomUUID().toString().replace("-",""));a.put(o);getPreferences(MODE_PRIVATE).edit().putString("profiles",a.toString()).apply();switchProfile(o.getString("id"));}catch(Exception e){error(e.getMessage());}}).show();}}).setNegativeButton("Cancel",null).show();
  }
  private void historyDialog(){List<String> records=db.history();String s=records.isEmpty()?"No purchases or transfers recorded yet.":String.join("\n\n",records);new AlertDialog.Builder(this).setTitle("Stock history (latest 100)").setMessage(s).setPositiveButton("Close",null).show();}
}
