package com.vappa.medicinetracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int EXPORT_CSV = 501;
    private static final int IMPORT_CSV = 502;
    private static final int BACKUP_JSON = 503;
    private static final int RESTORE_JSON = 504;

    // Crimson is branding, not a stock-status colour. Stock state uses green/amber/red.
    private static final int CRIMSON = Color.rgb(135, 25, 52);
    private static final int ROSE = Color.rgb(211, 54, 78);
    private static final int INK = Color.rgb(34, 43, 53);
    private static final int MUTED = Color.rgb(102, 115, 126);
    private static final int CANVAS = Color.rgb(248, 249, 251);
    private static final int BORDER = Color.rgb(228, 232, 236);
    private static final int GREEN = Color.rgb(23, 125, 82);
    private static final int GREEN_TINT = Color.rgb(232, 247, 238);
    private static final int AMBER = Color.rgb(154, 93, 11);
    private static final int AMBER_TINT = Color.rgb(255, 245, 224);
    private static final int DANGER = Color.rgb(185, 42, 57);
    private static final int RED_TINT = Color.rgb(255, 235, 236);

    private MedicineDb db;
    private String activeProfile = "default";
    private String searchTerm = "";
    // Urgent first by default: 0 = urgency, 1 = alphabetical, 2 = stock days.
    private int sortMode = 0;
    private LinearLayout root;
    private LinearLayout medicineList;
    private LinearLayout purchaseExpansion;
    private LinearLayout counters;
    private boolean purchaseExpanded = false;
    private final Set<Long> expandedMedicines = new HashSet<>();
    private String latestStockMessage = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(CRIMSON);
        getWindow().setNavigationBarColor(CANVAS);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        activeProfile = getPreferences(MODE_PRIVATE).getString("active_profile", "default");
        db = new MedicineDb(this, activeProfile);
        db.reconcile();
        DailyReceiver.schedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        draw();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null) {
            db.reconcile();
            if (root != null) draw();
        }
    }

    @Override protected void onDestroy() {
        if (db != null) db.close();
        super.onDestroy();
    }

    private int dp(float value) { return (int) (getResources().getDisplayMetrics().density * value + 0.5f); }
    private LinearLayout column() { LinearLayout out = new LinearLayout(this); out.setOrientation(LinearLayout.VERTICAL); return out; }
    private LinearLayout row() { LinearLayout out = new LinearLayout(this); out.setOrientation(LinearLayout.HORIZONTAL); out.setGravity(Gravity.CENTER_VERTICAL); return out; }
    private void padding(View view, int all) { view.setPadding(dp(all), dp(all), dp(all), dp(all)); }
    private void gap(LinearLayout parent, int space) { parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(space))); }
    private LinearLayout.LayoutParams margins(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }
    private GradientDrawable shape(int fill, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }
    private GradientDrawable outlined(int fill, int border, int radius) {
        GradientDrawable drawable = shape(fill, radius);
        drawable.setStroke(dp(1), border);
        return drawable;
    }
    private GradientDrawable brandGradient(int radius) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{CRIMSON, ROSE});
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }
    private TextView action(String label, boolean primary, Runnable onTap) {
        TextView view = text(label, 15, primary ? Color.WHITE : CRIMSON, true);
        view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(48));
        view.setPadding(dp(15), dp(10), dp(15), dp(10));
        view.setBackground(primary ? brandGradient(13) : outlined(Color.WHITE, BORDER, 13));
        view.setClickable(true);
        view.setFocusable(true);
        view.setOnClickListener(v -> onTap.run());
        return view;
    }
    private TextView link(String label, int color, Runnable onTap) {
        TextView view = text(label, 14, color, true);
        view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(48));
        view.setPadding(dp(10), dp(8), dp(10), dp(8));
        view.setClickable(true);
        view.setFocusable(true);
        view.setOnClickListener(v -> onTap.run());
        return view;
    }
    private String fmt(double number) {
        if (Math.abs(number) < 0.0000001) return "0";
        if (Math.abs(number - Math.rint(number)) < 0.00001) return String.format(Locale.US, "%.0f", number);
        return String.format(Locale.US, "%.2f", number).replaceAll("0+$", "").replaceAll("\\.$", "");
    }
    private String pluralDays(long days) { return days == 1 ? "1 day" : days + " days"; }
    private boolean visitSet() { return !db.getVisit().isEmpty(); }
    private double neededToBuy(MedicineDb.Medicine m) {
        if (!visitSet() || m.daily <= 0) return 0;
        return Math.max(0, m.daily * db.daysToVisit() - m.total());
    }
    private long purchaseQuantity(MedicineDb.Medicine m) {
        double missing = neededToBuy(m);
        return missing <= 0.000001 ? 0 : (long) Math.ceil(missing - 0.000001);
    }
    private int urgency(MedicineDb.Medicine m) {
        if (m.daily <= 0) return 4;
        if (m.total() <= 0.000001) return 0;
        if (m.daysLeft() <= 7.000001) return 1;
        if (purchaseQuantity(m) > 0) return 2;
        return 3;
    }
    private int statusColor(int urgency) {
        if (urgency <= 1) return DANGER;
        if (urgency == 2) return AMBER;
        if (urgency == 3) return GREEN;
        return MUTED;
    }
    private int statusTint(int urgency) {
        if (urgency <= 1) return RED_TINT;
        if (urgency == 2) return AMBER_TINT;
        if (urgency == 3) return GREEN_TINT;
        return CANVAS;
    }
    private String statusName(int urgency) {
        switch (urgency) {
            case 0: return "OUT OF STOCK";
            case 1: return "REORDER NOW";
            case 2: return "PURCHASE NEEDED";
            case 3: return visitSet() ? "ADEQUATE" : "IN STOCK";
            default: return "NOT SCHEDULED";
        }
    }
    private String stockDays(MedicineDb.Medicine m) {
        if (m.daily <= 0) return "Not scheduled";
        double days = m.daysLeft();
        if (days < 0.00001) return "0 days";
        if (days < 1) return "Less than 1 day";
        return "About " + pluralDays((long) Math.floor(days + 0.000001));
    }

    private void draw() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(CANVAS);
        root = column();
        root.setPadding(dp(16), dp(16), dp(16), dp(22));
        scroll.addView(root);
        setContentView(scroll);

        drawHeader();
        gap(root, 14);
        drawVisit();
        gap(root, 12);
        drawDashboard();
        gap(root, 12);
        drawActions();
        if (!latestStockMessage.isEmpty()) drawUndoNotice();
        gap(root, 22);

        LinearLayout heading = row();
        heading.addView(text("MY MEDICINES", 13, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1));
        heading.addView(text("Urgent first", 12, MUTED, false));
        root.addView(heading);
        gap(root, 9);

        LinearLayout filters = row();
        EditText search = field("Search medicines", searchTerm, false);
        search.setSingleLine(true);
        search.setMinHeight(dp(52));
        search.setBackground(outlined(Color.WHITE, BORDER, 12));
        search.setPadding(dp(12), dp(7), dp(12), dp(7));
        filters.addView(search, new LinearLayout.LayoutParams(0, dp(52), 1));
        Spinner sort = new Spinner(this);
        sort.setContentDescription("Sort medicines");
        sort.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Urgency", "A–Z", "Stock days"}));
        sort.setSelection(sortMode);
        sort.setBackground(outlined(Color.WHITE, BORDER, 12));
        filters.addView(sort, margins(dp(116), dp(52), 8, 0, 0, 0));
        root.addView(filters);
        gap(root, 11);
        medicineList = column();
        root.addView(medicineList);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchTerm = s.toString(); refreshCards();
            }
            public void afterTextChanged(Editable editable) { }
        });
        sort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sortMode = position; refreshCards();
            }
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        refreshCards();
        gap(root, 14);
        root.addView(text("Stock is estimated from the daily requirement. Box 1 is used before backup. Edit quantities if actual use differs.", 12, MUTED, false));
    }

    private void drawHeader() {
        LinearLayout header = row();
        padding(header, 14);
        header.setMinimumHeight(dp(84));
        header.setBackground(brandGradient(18));
        TextView menu = text("⋮", 30, Color.WHITE, true);
        menu.setGravity(Gravity.CENTER);
        menu.setBackground(shape(Color.argb(35, 255, 255, 255), 12));
        menu.setContentDescription("Open app menu");
        menu.setClickable(true);
        menu.setFocusable(true);
        header.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        menu.setOnClickListener(v -> showMenu());

        LinearLayout heading = column();
        TextView title = text("Vappa Medicine Tracker", 19, Color.WHITE, true);
        title.setMaxLines(2);
        heading.addView(title);
        TextView profile = text("◉  " + profileLabel() + "  ▾  •  Offline", 12, Color.rgb(255, 235, 237), false);
        profile.setMinHeight(dp(38));
        profile.setGravity(Gravity.CENTER_VERTICAL);
        profile.setContentDescription("Current patient " + profileLabel() + ". Tap to switch patients");
        profile.setOnClickListener(v -> profileDialog());
        heading.addView(profile);
        header.addView(heading, margins(0, -2, 12, 0, 0, 0));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) heading.getLayoutParams();
        params.weight = 1;
        heading.setLayoutParams(params);
        root.addView(header);
    }

    private void drawVisit() {
        LinearLayout visit = row();
        padding(visit, 16);
        visit.setMinimumHeight(dp(90));
        visit.setBackground(outlined(Color.WHITE, BORDER, 17));
        LinearLayout dates = column();
        dates.addView(text("NEXT HOSPITAL VISIT", 11, MUTED, true));
        gap(dates, 5);
        dates.addView(text(visitSet() ? getVisitLabel() : "Not set", 18, INK, true));
        gap(dates, 3);
        dates.addView(text(visitSet() ? (pluralDays(db.daysToVisit()) + " remaining") : "Set a date to calculate purchases", 12, MUTED, false));
        visit.addView(dates, new LinearLayout.LayoutParams(0, -2, 1));
        TextView edit = link("Edit  ✎", CRIMSON, this::dateDialog);
        visit.addView(edit);
        visit.setContentDescription("Next hospital visit. Tap to change the date");
        visit.setOnClickListener(v -> dateDialog());
        root.addView(visit);
    }

    private LinearLayout statTile(String count, String caption, int valueColor, boolean clickable, Runnable onTap) {
        LinearLayout tile = column();
        tile.setGravity(Gravity.CENTER);
        tile.setMinHeight(dp(94));
        tile.setPadding(dp(5), dp(9), dp(5), dp(9));
        tile.setBackground(outlined(Color.WHITE, BORDER, 14));
        tile.addView(text(count, 24, valueColor, true));
        TextView label = text(caption, 11, MUTED, true);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        tile.addView(label);
        if (clickable) {
            tile.setClickable(true);
            tile.setFocusable(true);
            tile.setOnClickListener(v -> onTap.run());
            tile.setContentDescription(count + " " + caption + ". Show or hide the purchase list.");
        }
        return tile;
    }
    private void drawDashboard() {
        LinearLayout panel = column();
        LinearLayout titleRow = row();
        titleRow.addView(text("STOCK OVERVIEW", 12, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1));
        titleRow.addView(text("Updated today", 11, MUTED, false));
        panel.addView(titleRow);
        gap(panel, 8);
        counters = row();
        panel.addView(counters);
        root.addView(panel);
        gap(root, 8);
        LinearLayout purchase = column();
        purchase.setPadding(dp(13), dp(3), dp(13), dp(7));
        purchase.setBackground(outlined(Color.WHITE, BORDER, 13));
        TextView toggle = link(purchaseExpanded ? "⌃   Hide purchase list" : "⌄   View medicines to purchase", CRIMSON,
                () -> { purchaseExpanded = !purchaseExpanded; draw(); });
        toggle.setGravity(Gravity.CENTER_VERTICAL);
        purchase.addView(toggle);
        purchaseExpansion = column();
        purchase.addView(purchaseExpansion);
        root.addView(purchase);
    }
    private void drawActions() {
        LinearLayout actions = row();
        actions.addView(action("+ Stock", true, this::stockDialog), new LinearLayout.LayoutParams(0, dp(52), 1));
        actions.addView(action("+ Medicine", false, () -> editDialog(null)), margins(0, dp(52), 9, 0, 0, 0));
        LinearLayout.LayoutParams p = (LinearLayout.LayoutParams) actions.getChildAt(1).getLayoutParams();
        p.weight = 1;
        actions.getChildAt(1).setLayoutParams(p);
        root.addView(actions);
    }
    private void drawUndoNotice() {
        LinearLayout banner = row();
        banner.setPadding(dp(12), dp(5), dp(8), dp(5));
        banner.setBackground(outlined(GREEN_TINT, Color.rgb(181, 221, 198), 12));
        TextView note = text(latestStockMessage, 12, INK, false);
        note.setMaxLines(3);
        banner.addView(note, new LinearLayout.LayoutParams(0, -2, 1));
        banner.addView(link("Undo", GREEN, () -> {
            String failure = db.undoLatest();
            if (failure != null) { error(failure); return; }
            latestStockMessage = "";
            draw();
            message("Transaction undone", "The most recent purchase or transfer was reversed.");
        }));
        root.addView(banner, margins(-1, -2, 0, 10, 0, 0));
    }

    private void refreshCards() {
        if (medicineList == null || counters == null) return;
        List<MedicineDb.Medicine> all = db.all();
        int low = 0, need = 0;
        for (MedicineDb.Medicine m : all) {
            if (m.daily > 0 && m.daysLeft() <= 7.000001) low++;
            if (purchaseQuantity(m) > 0) need++;
        }
        counters.removeAllViews();
        LinearLayout total = statTile(Integer.toString(all.size()), "Medicines", INK, false, null);
        LinearLayout lowCount = statTile(Integer.toString(low), "Low stock", low > 0 ? DANGER : GREEN, false, null);
        LinearLayout toBuy = statTile(Integer.toString(need), "To buy  ▾", need > 0 ? AMBER : GREEN,
                true, () -> { purchaseExpanded = !purchaseExpanded; draw(); });
        counters.addView(total, new LinearLayout.LayoutParams(0, -2, 1));
        counters.addView(lowCount, margins(0, -2, 7, 0, 0, 0));
        ((LinearLayout.LayoutParams) lowCount.getLayoutParams()).weight = 1;
        counters.addView(toBuy, margins(0, -2, 7, 0, 0, 0));
        ((LinearLayout.LayoutParams) toBuy.getLayoutParams()).weight = 1;

        refreshPurchaseList(all);
        medicineList.removeAllViews();
        List<MedicineDb.Medicine> visible = new ArrayList<>(all);
        String query = searchTerm.toLowerCase(Locale.ROOT).trim();
        visible.removeIf(m -> !m.name.toLowerCase(Locale.ROOT).contains(query));
        if (sortMode == 0) {
            Collections.sort(visible, (a, b) -> {
                int first = Integer.compare(urgency(a), urgency(b));
                if (first != 0) return first;
                int days = Double.compare(a.daysLeft(), b.daysLeft());
                return days != 0 ? days : a.name.compareToIgnoreCase(b.name);
            });
        } else if (sortMode == 2) {
            Collections.sort(visible, (a, b) -> Double.compare(a.daysLeft(), b.daysLeft()));
        } else {
            Collections.sort(visible, (a, b) -> a.name.compareToIgnoreCase(b.name));
        }
        if (all.isEmpty()) { drawEmptyState(); return; }
        if (visible.isEmpty()) {
            LinearLayout empty = column(); padding(empty, 18);
            empty.setBackground(outlined(Color.WHITE, BORDER, 15));
            empty.addView(text("No matching medicines", 16, INK, true));
            gap(empty, 4);
            empty.addView(text("Try another name or clear the search.", 13, MUTED, false));
            medicineList.addView(empty);
            return;
        }
        for (MedicineDb.Medicine medicine : visible) drawMedicineCard(medicine);
    }

    private void drawEmptyState() {
        LinearLayout empty = column();
        padding(empty, 22);
        empty.setBackground(outlined(Color.WHITE, BORDER, 17));
        empty.addView(text("No medicines yet", 19, INK, true));
        gap(empty, 6);
        empty.addView(text("Add your first medicine, or restore your previously saved medicine data from a JSON file.", 14, MUTED, false));
        gap(empty, 14);
        empty.addView(action("+ Add first medicine", true, () -> editDialog(null)));
        gap(empty, 9);
        empty.addView(action("Restore JSON backup", false,
                () -> documentPicker(Intent.ACTION_OPEN_DOCUMENT, "application/json", null, RESTORE_JSON)));
        medicineList.addView(empty);
    }

    private void refreshPurchaseList(List<MedicineDb.Medicine> medicines) {
        if (purchaseExpansion == null) return;
        purchaseExpansion.removeAllViews();
        if (!purchaseExpanded) return;
        if (!visitSet()) {
            purchaseExpansion.addView(text("Set your next hospital visit to calculate how many tablets to buy.", 13, MUTED, false));
            purchaseExpansion.addView(link("Set visit date", CRIMSON, this::dateDialog));
            return;
        }
        purchaseExpansion.addView(text("TO PURCHASE BY " + getVisitLabel().toUpperCase(Locale.ENGLISH), 11, MUTED, true));
        gap(purchaseExpansion, 5);
        List<MedicineDb.Medicine> purchasing = new ArrayList<>();
        for (MedicineDb.Medicine medicine : medicines) if (purchaseQuantity(medicine) > 0) purchasing.add(medicine);
        Collections.sort(purchasing, (a, b) -> Integer.compare(urgency(a), urgency(b)));
        if (purchasing.isEmpty()) {
            purchaseExpansion.addView(text("✓  Nothing to purchase for this visit.", 14, GREEN, true));
        } else {
            for (MedicineDb.Medicine medicine : purchasing) {
                LinearLayout line = row();
                line.setMinHeight(dp(40));
                line.addView(text(medicine.name, 14, INK, false), new LinearLayout.LayoutParams(0, -2, 1));
                line.addView(text(purchaseQuantity(medicine) + " tablets", 14,
                        urgency(medicine) <= 1 ? DANGER : AMBER, true));
                purchaseExpansion.addView(line);
            }
            purchaseExpansion.addView(link("Share list with pharmacy  ↗", CRIMSON, this::sharePurchaseList));
        }
    }

    private void drawMedicineCard(MedicineDb.Medicine medicine) {
        int state = urgency(medicine);
        int colour = statusColor(state);
        LinearLayout card = column();
        padding(card, 16);
        card.setBackground(outlined(Color.WHITE, BORDER, 17));
        LinearLayout top = row();
        TextView name = text(medicine.name, 17, INK, true);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text(statusName(state), 10, colour, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(9), dp(6), dp(9), dp(6));
        badge.setBackground(shape(statusTint(state), 9));
        top.addView(badge, margins(-2, -2, 5, 0, 0, 0));
        card.addView(top);
        gap(card, 14);

        LinearLayout figures = row();
        LinearLayout quantity = column();
        quantity.addView(text("TOTAL AVAILABLE", 10, MUTED, true));
        gap(quantity, 4);
        quantity.addView(text(fmt(medicine.total()) + " tablets", 18, INK, true));
        figures.addView(quantity, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout duration = column();
        duration.setGravity(Gravity.RIGHT);
        TextView title = text("STOCK LASTS", 10, MUTED, true);
        title.setGravity(Gravity.RIGHT);
        duration.addView(title);
        gap(duration, 4);
        TextView remaining = text(stockDays(medicine), 15, colour, true);
        remaining.setGravity(Gravity.RIGHT);
        duration.addView(remaining);
        figures.addView(duration);
        card.addView(figures);
        gap(card, 13);
        String message;
        if (state == 0) message = "No tablets available — reorder now";
        else if (state == 1) message = "Only seven days or less remaining";
        else if (state == 2) message = "Buy " + purchaseQuantity(medicine) + " tablets for next visit";
        else if (state == 3) message = visitSet() ? "Enough stock until your next visit" : "Stock available — set visit date to plan";
        else message = "No daily medicine requirement scheduled";
        card.addView(text(message, 13, colour, true));

        LinearLayout controls = row();
        boolean opened = expandedMedicines.contains(medicine.id);
        TextView details = link(opened ? "Hide details  ⌃" : "View details  ⌄", MUTED, () -> {
            if (!expandedMedicines.add(medicine.id)) expandedMedicines.remove(medicine.id);
            refreshCards();
        });
        controls.addView(details, new LinearLayout.LayoutParams(0, dp(48), 1));
        controls.addView(link("Edit  ✎", CRIMSON, () -> editDialog(medicine)));
        card.addView(controls);
        if (opened) {
            View divider = new View(this);
            divider.setBackgroundColor(BORDER);
            card.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
            gap(card, 11);
            card.addView(text("Box 1: " + fmt(medicine.b1) + "     •     Backup: " + fmt(medicine.b2), 13, INK, false));
            gap(card, 6);
            card.addView(text("Daily: " + fmt(medicine.daily) + " tablets", 13, INK, false));
            if (medicine.daily > 0) {
                gap(card, 6);
                card.addView(text("Exact supply: " + fmt(medicine.daysLeft()) + " days", 13, MUTED, false));
            }
            if (visitSet()) {
                gap(card, 6);
                card.addView(text("Needed until visit: " + fmt(medicine.daily * db.daysToVisit())
                        + "     •     Buy: " + purchaseQuantity(medicine), 13,
                        purchaseQuantity(medicine) > 0 ? colour : GREEN, true));
            }
        }
        medicineList.addView(card);
        gap(medicineList, 10);
    }

    private void showMenu() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout options = column();
        padding(options, 16);
        scroll.addView(options);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Vappa Medicine Tracker").setView(scroll)
                .setNegativeButton("Close", null).create();
        section(options, "INVENTORY");
        menuEntry(options, "Medicines", "View, search and edit medicines", () -> { dialog.dismiss(); medicineListDialog(); });
        menuEntry(options, "Purchase list", "See and share medicines to buy", () -> { dialog.dismiss(); purchaseDialog(); });
        menuEntry(options, "Stock history", "Purchases, transfers and undo entries", () -> { dialog.dismiss(); historyDialog(); });
        section(options, "PATIENTS & DATA");
        menuEntry(options, "Switch / add patient", "Separate stock for each family member", () -> { dialog.dismiss(); profileDialog(); });
        menuEntry(options, "Excel import / export", "CSV format for Excel and Sheets", () -> { dialog.dismiss(); excelDialog(); });
        menuEntry(options, "Backup JSON", "Save current patient's data", () -> {
            dialog.dismiss(); documentPicker(Intent.ACTION_CREATE_DOCUMENT, "application/json", "Vappa_Medicine_Backup.json", BACKUP_JSON);
        });
        menuEntry(options, "Restore JSON", "Preview before replacing patient data", () -> {
            dialog.dismiss(); documentPicker(Intent.ACTION_OPEN_DOCUMENT, "application/json", null, RESTORE_JSON);
        });
        section(options, "PREFERENCES");
        menuEntry(options, "Settings", "Notifications, visit date and inventory controls", () -> { dialog.dismiss(); settingsDialog(); });
        dialog.show();
    }

    private void section(LinearLayout parent, String title) {
        gap(parent, 10);
        parent.addView(text(title, 11, CRIMSON, true));
        gap(parent, 4);
    }
    private void menuEntry(LinearLayout parent, String title, String subtitle, Runnable onTap) {
        LinearLayout entry = row();
        entry.setMinHeight(dp(59));
        entry.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout captions = column();
        captions.addView(text(title, 15, INK, true));
        captions.addView(text(subtitle, 12, MUTED, false));
        entry.addView(captions, new LinearLayout.LayoutParams(0, -2, 1));
        entry.addView(text("›", 21, MUTED, false));
        entry.setOnClickListener(v -> onTap.run());
        entry.setContentDescription(title);
        entry.setFocusable(true);
        parent.addView(entry);
        View line = new View(this); line.setBackgroundColor(BORDER);
        parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
    }
    private void excelDialog() {
        new AlertDialog.Builder(this).setTitle("Excel conversion (CSV)")
                .setItems(new String[]{"Export medicines as CSV", "Import medicines from CSV"}, (d, index) -> {
                    if (index == 0) documentPicker(Intent.ACTION_CREATE_DOCUMENT, "text/csv", "Vappa_Medicines.csv", EXPORT_CSV);
                    else documentPicker(Intent.ACTION_OPEN_DOCUMENT, "text/*", null, IMPORT_CSV);
                }).setNegativeButton("Cancel", null).show();
    }
    private void settingsDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout contents = column(); padding(contents, 18); scroll.addView(contents);
        contents.addView(text("Next visit: " + getVisitLabel(), 16, INK, true));
        gap(contents, 10);
        contents.addView(text("Low-stock alerts: one combined reminder per day at 9:00 AM IST when any active medicine has 7 days or less of stock. Android may delay delivery.", 14, MUTED, false));
        gap(contents, 10);
        contents.addView(text("Automatic stock estimates use Box 1 first and backup second. Adjust quantities when real consumption differs.", 14, MUTED, false));
        gap(contents, 15);
        contents.addView(action("Change hospital visit date", false, this::dateDialog));
        gap(contents, 10);
        contents.addView(action("Undo latest purchase / transfer", false, () ->
                new AlertDialog.Builder(this).setTitle("Undo last transaction?")
                        .setMessage("This can reverse the last purchase or transfer if the stock is still available. Daily consumption is not undone.")
                        .setNegativeButton("Cancel", null).setPositiveButton("Undo", (d, w) -> {
                            String result = db.undoLatest();
                            if (result == null) { latestStockMessage = ""; draw(); message("Transaction undone", "Stock quantities have been restored."); }
                            else error(result);
                        }).show()));
        gap(contents, 10);
        contents.addView(action("Clear medicines and stock history", false, () ->
                new AlertDialog.Builder(this).setTitle("Clear medicine inventory?")
                        .setMessage("This permanently deletes the active patient's medicines and stock history. The visit date remains. Back up as JSON first if you need these records.")
                        .setNegativeButton("Cancel", null).setPositiveButton("Clear inventory", (d, w) -> {
                            db.clearInventory(); latestStockMessage = ""; expandedMedicines.clear();
                            draw(); message("Inventory cleared", "Add medicines or restore a JSON backup from the menu.");
                        }).show()));
        new AlertDialog.Builder(this).setTitle("Settings").setView(scroll).setPositiveButton("Close", null).show();
    }
    private void medicineListDialog() {
        List<MedicineDb.Medicine> list = db.all();
        String[] options = new String[list.size() + 1];
        options[0] = "+ Add new medicine";
        for (int i = 0; i < list.size(); i++) options[i + 1] = list.get(i).name;
        new AlertDialog.Builder(this).setTitle("Medicine list • select to edit")
                .setItems(options, (d, position) -> {
                    if (position == 0) editDialog(null);
                    else editDialog(list.get(position - 1));
                }).setNegativeButton("Close", null).show();
    }

    private EditText field(String hint, String initial, boolean numeric) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setHint(hint);
        input.setText(initial);
        if (numeric) input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setMinHeight(dp(48));
        return input;
    }
    private void addField(LinearLayout parent, String caption, EditText input) {
        parent.addView(text(caption, 13, MUTED, true));
        parent.addView(input);
        gap(parent, 9);
    }
    private Double positiveOrZero(EditText input) {
        try {
            double value = Double.parseDouble(input.getText().toString().trim());
            return Double.isFinite(value) && value >= 0 && value <= 100000000 ? value : null;
        } catch (Exception ignored) { return null; }
    }
    private void editDialog(MedicineDb.Medicine current) {
        boolean existing = current != null;
        ScrollView scroll = new ScrollView(this);
        LinearLayout form = column(); padding(form, 18); scroll.addView(form);
        EditText name = field("Medicine name", existing ? current.name : "", false);
        EditText daily = field("Daily requirement", existing ? fmt(current.daily) : "1", true);
        EditText box1 = field("Box 1", existing ? fmt(current.b1) : "0", true);
        EditText box2 = field("Box 2", existing ? fmt(current.b2) : "0", true);
        addField(form, "MEDICINE NAME", name);
        addField(form, "TABLETS PER DAY • decimals allowed", daily);
        addField(form, "BOX 1 — current use", box1);
        addField(form, "BOX 2 — backup", box2);
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(existing ? "Edit medicine" : "Add medicine")
                .setView(scroll).setNegativeButton("Cancel", null).setPositiveButton("Save", null);
        if (existing) builder.setNeutralButton("Delete", (d, w) ->
                new AlertDialog.Builder(this).setTitle("Delete " + current.name + "?")
                        .setMessage("The medicine will be removed. This cannot be undone.")
                        .setNegativeButton("Cancel", null).setPositiveButton("Delete", (confirm, which) -> {
                            db.delete(current.id); expandedMedicines.remove(current.id); draw();
                        }).show());
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w -> {
            String medicineName = name.getText().toString().trim();
            Double requirement = positiveOrZero(daily), first = positiveOrZero(box1), backup = positiveOrZero(box2);
            if (medicineName.isEmpty() || medicineName.length() > 200 || requirement == null || first == null || backup == null) {
                error("Enter a medicine name and valid non-negative quantities."); return;
            }
            db.upsert(existing ? current.id : null, medicineName, requirement, first, backup);
            dialog.dismiss(); draw();
        }));
        dialog.show();
    }

    // Full-height entry sheet with a scrollable form and a pinned Save button.
    private void stockDialog() {
        List<MedicineDb.Medicine> meds = db.all();
        if (meds.isEmpty()) { error("Add a medicine first."); return; }
        Dialog sheet = new Dialog(this);
        sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout layout = column();
        layout.setBackgroundColor(CANVAS);

        LinearLayout header = row(); padding(header, 14);
        header.setBackgroundColor(Color.WHITE);
        TextView heading = text("Add / Transfer Stock", 20, INK, true);
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(link("✕", MUTED, sheet::dismiss));
        layout.addView(header);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false);
        LinearLayout form = column(); padding(form, 18); scroll.addView(form);
        form.addView(text("MEDICINE", 12, MUTED, true));
        Spinner medicine = new Spinner(this);
        String[] names = new String[meds.size()];
        for (int i = 0; i < meds.size(); i++) names[i] = meds.get(i).name;
        medicine.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        form.addView(medicine, new LinearLayout.LayoutParams(-1, dp(50)));
        gap(form, 11);

        form.addView(text("STOCK ACTION", 12, MUTED, true));
        Spinner type = new Spinner(this);
        type.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Purchase new stock", "Transfer Backup → Box 1"}));
        form.addView(type, new LinearLayout.LayoutParams(-1, dp(50)));
        gap(form, 11);
        TextView destinationTitle = text("ADD PURCHASE TO", 12, MUTED, true);
        form.addView(destinationTitle);
        Spinner destination = new Spinner(this);
        destination.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Box 1 (current use)", "Box 2 (backup)"}));
        destination.setSelection(1); // Default new purchases to backup stock.
        form.addView(destination, new LinearLayout.LayoutParams(-1, dp(50)));
        gap(form, 10);

        form.addView(text("QUANTITY CALCULATOR", 12, MUTED, true));
        EditText expression = field("e.g. 10+20 or 6×10", "", false);
        expression.setTextSize(22);
        expression.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        expression.setShowSoftInputOnFocus(false);
        expression.setBackground(outlined(Color.WHITE, BORDER, 12));
        expression.setPadding(dp(14), dp(6), dp(14), dp(6));
        form.addView(expression, new LinearLayout.LayoutParams(-1, dp(60)));
        gap(form, 8);
        TextView calculation = text("Enter a quantity or calculation", 14, MUTED, false);
        form.addView(calculation);
        gap(form, 12);
        addCalculator(form, expression);
        gap(form, 8);
        TextView hint = text("The total stock will update only after you tap Save.", 12, MUTED, false);
        form.addView(hint);
        layout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout footer = column(); padding(footer, 14);
        footer.setBackgroundColor(Color.WHITE);
        TextView result = text("Enter the amount to continue", 13, MUTED, false);
        footer.addView(result);
        gap(footer, 7);
        TextView save = action("Save stock change", true, () -> {
            Double amount = calculateQuantity(expression.getText().toString());
            if (amount == null || amount <= 0 || amount > 100000000) {
                error("Please enter a valid positive quantity. Try 10+20 or 6×10."); return;
            }
            MedicineDb.Medicine selected = meds.get(medicine.getSelectedItemPosition());
            boolean transfer = type.getSelectedItemPosition() == 1;
            boolean toBackup = destination.getSelectedItemPosition() == 1;
            String failure = db.stockAction(selected.id, transfer, toBackup, amount);
            if (failure != null) { error(failure); return; }
            latestStockMessage = transfer
                    ? "Transferred " + fmt(amount) + " tablets of " + selected.name + " to Box 1"
                    : "Added " + fmt(amount) + " tablets of " + selected.name + " to " + (toBackup ? "Backup" : "Box 1");
            sheet.dismiss(); draw();
        });
        footer.addView(save);
        layout.addView(footer);

        Runnable update = () -> {
            boolean transfer = type.getSelectedItemPosition() == 1;
            destination.setVisibility(transfer ? View.GONE : View.VISIBLE);
            destinationTitle.setVisibility(transfer ? View.GONE : View.VISIBLE);
            Double q = calculateQuantity(expression.getText().toString());
            if (q == null || q <= 0) {
                calculation.setText("Enter a valid positive calculation");
                result.setText("Enter the amount to continue");
                return;
            }
            calculation.setText("= " + fmt(q) + " tablets");
            result.setText(transfer
                    ? "Transfer " + fmt(q) + " from Backup to Box 1"
                    : "Add " + fmt(q) + " tablets to " + (destination.getSelectedItemPosition() == 1 ? "Backup" : "Box 1"));
        };
        expression.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { update.run(); }
            public void afterTextChanged(Editable editable) { }
        });
        AdapterView.OnItemSelectedListener watcher = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int position, long id) { update.run(); }
            public void onNothingSelected(AdapterView<?> p) { }
        };
        type.setOnItemSelectedListener(watcher);
        destination.setOnItemSelectedListener(watcher);
        update.run();
        sheet.setContentView(layout);
        sheet.show();
        Window window = sheet.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            window.setStatusBarColor(CRIMSON);
            window.setNavigationBarColor(CANVAS);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
    }
    private Double calculateQuantity(String expression) {
        if (expression == null || expression.isEmpty() || expression.length() > 120) return null;
        try {
            double number = new QuantityParser(expression).parse();
            return Double.isFinite(number) && number >= 0 && number <= 100000000
                    ? Math.round(number * 1000000d) / 1000000d : null;
        } catch (Exception ignored) { return null; }
    }
    private static class QuantityParser {
        private final String input;
        private int cursor;
        QuantityParser(String s) {
            input = s.replace('×', '*').replace('÷', '/').replace('−', '-').replace(" ", "");
        }
        private boolean take(char ch) {
            if (cursor < input.length() && input.charAt(cursor) == ch) { cursor++; return true; }
            return false;
        }
        double parse() {
            double value = expression();
            if (cursor != input.length()) throw new IllegalArgumentException("Invalid expression");
            return value;
        }
        private double expression() {
            double value = term();
            while (true) {
                if (take('+')) value += term();
                else if (take('-')) value -= term();
                else return value;
            }
        }
        private double term() {
            double value = number();
            while (true) {
                if (take('*')) value *= number();
                else if (take('/')) {
                    double divisor = number();
                    if (divisor == 0) throw new ArithmeticException("Divide by zero");
                    value /= divisor;
                } else return value;
            }
        }
        private double number() {
            if (take('+')) return number();
            if (take('-')) return -number();
            int begin = cursor;
            boolean dot = false;
            while (cursor < input.length()) {
                char ch = input.charAt(cursor);
                if (ch == '.' && !dot) { dot = true; cursor++; }
                else if (ch >= '0' && ch <= '9') cursor++;
                else break;
            }
            if (cursor == begin) throw new IllegalArgumentException("Number required");
            return Double.parseDouble(input.substring(begin, cursor));
        }
    }
    private void addCalculator(LinearLayout form, EditText input) {
        String[][] keys = {
                {"7", "8", "9", "÷"},
                {"4", "5", "6", "×"},
                {"1", "2", "3", "−"},
                {"C", "0", ".", "+"},
                {"⌫", "00", "="}
        };
        for (String[] line : keys) {
            LinearLayout row = row();
            for (String key : line) {
                boolean equal = "=".equals(key);
                boolean operator = "÷×−+".contains(key) && key.length() == 1;
                TextView button = text(key, 21, equal ? Color.WHITE : (operator ? CRIMSON : INK), true);
                button.setGravity(Gravity.CENTER);
                button.setMinHeight(dp(49));
                button.setBackground(equal ? brandGradient(10) : outlined(Color.WHITE, BORDER, 10));
                row.addView(button, margins(0, dp(49), 2, 2, 2, 2));
                LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) button.getLayoutParams();
                params.weight = 1; button.setLayoutParams(params);
                button.setContentDescription("Calculator " + key);
                button.setOnClickListener(v -> {
                    String value = input.getText().toString();
                    if ("C".equals(key)) input.setText("");
                    else if ("⌫".equals(key)) {
                        if (!value.isEmpty()) input.setText(value.substring(0, value.length() - 1));
                    } else if (equal) {
                        Double result = calculateQuantity(value);
                        if (result == null) { error("Invalid calculation. Please check the expression."); return; }
                        input.setText(fmt(result));
                    } else if (value.length() < 120) input.setText(value + key);
                    input.setSelection(input.length());
                });
            }
            form.addView(row);
        }
    }

    private String getVisitLabel() {
        if (!visitSet()) return "Not set";
        try { return LocalDate.parse(db.getVisit()).format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)); }
        catch (Exception e) { return db.getVisit(); }
    }
    private void dateDialog() {
        LocalDate initial;
        try { initial = LocalDate.parse(db.getVisit()); }
        catch (Exception ignored) { initial = LocalDate.now().plusMonths(1); }
        DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
            db.setVisit(LocalDate.of(year, month + 1, day).toString());
            draw();
        }, initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth());
        picker.setTitle("Next hospital visit");
        picker.show();
    }
    private String purchaseText() {
        if (!visitSet()) return "Set your next hospital visit first.";
        StringBuilder builder = new StringBuilder();
        List<MedicineDb.Medicine> meds = db.all();
        Collections.sort(meds, (a, b) -> Integer.compare(urgency(a), urgency(b)));
        for (MedicineDb.Medicine m : meds) {
            if (purchaseQuantity(m) > 0) builder.append("• ").append(m.name).append(": ")
                    .append(purchaseQuantity(m)).append(" tablets\n");
        }
        return builder.length() == 0 ? "All medicines have enough stock until the next visit." : builder.toString().trim();
    }
    private void sharePurchaseList() {
        if (!visitSet()) { error("Please set a next hospital visit date before sharing."); return; }
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Medicines to purchase until " + getVisitLabel()
                + "\nPatient: " + profileLabel() + "\n\n" + purchaseText());
        startActivity(Intent.createChooser(intent, "Share with pharmacy"));
    }
    private void purchaseDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Purchase list" + (visitSet() ? " • " + getVisitLabel() : ""))
                .setMessage(purchaseText()).setPositiveButton("Close", null);
        if (visitSet()) builder.setNeutralButton("Share with pharmacy", (d, w) -> sharePurchaseList());
        else builder.setNeutralButton("Set visit date", (d, w) -> dateDialog());
        builder.show();
    }
    private void historyDialog() {
        List<String> entries = db.history();
        if (entries.isEmpty()) { message("Stock history", "No stock purchases or transfers have been recorded yet."); return; }
        ScrollView scroll = new ScrollView(this);
        LinearLayout container = column(); padding(container, 14); scroll.addView(container);
        for (String entry : entries) {
            String[] parts = entry.split("\\n", 2);
            LinearLayout card = column(); padding(card, 13);
            card.setBackground(outlined(Color.WHITE, BORDER, 12));
            card.addView(text(parts[0], 13, INK, true));
            if (parts.length > 1) { gap(card, 5); card.addView(text(parts[1], 13, MUTED, false)); }
            container.addView(card); gap(container, 8);
        }
        new AlertDialog.Builder(this).setTitle("Stock history • latest 100").setView(scroll)
                .setPositiveButton("Close", null).show();
    }

    private JSONArray profiles() {
        try { return new JSONArray(getPreferences(MODE_PRIVATE).getString("profiles", "[{\"id\":\"default\",\"name\":\"Vappa\"}]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }
    private String profileLabel() {
        JSONArray profiles = profiles();
        for (int i = 0; i < profiles.length(); i++) {
            JSONObject profile = profiles.optJSONObject(i);
            if (profile != null && activeProfile.equals(profile.optString("id")))
                return profile.optString("name", "Vappa");
        }
        return "Vappa";
    }
    private void switchProfile(String id) {
        if (db != null) db.close();
        activeProfile = id;
        getPreferences(MODE_PRIVATE).edit().putString("active_profile", id).apply();
        db = new MedicineDb(this, activeProfile);
        db.reconcile();
        searchTerm = ""; latestStockMessage = ""; expandedMedicines.clear();
        draw();
    }
    private void profileDialog() {
        JSONArray profiles = profiles();
        String[] labels = new String[profiles.length() + 1];
        for (int i = 0; i < profiles.length(); i++) {
            JSONObject profile = profiles.optJSONObject(i);
            labels[i] = profile.optString("name", "Patient")
                    + (activeProfile.equals(profile.optString("id")) ? "  ✓" : "");
        }
        labels[profiles.length()] = "+ Add patient";
        new AlertDialog.Builder(this).setTitle("Choose patient").setItems(labels, (d, selected) -> {
            if (selected < profiles.length()) {
                switchProfile(profiles.optJSONObject(selected).optString("id"));
            } else {
                EditText input = field("Patient name", "", false);
                new AlertDialog.Builder(this).setTitle("New patient profile").setView(input)
                        .setNegativeButton("Cancel", null).setPositiveButton("Add", (dialog, which) -> {
                            String value = input.getText().toString().trim();
                            if (value.isEmpty() || value.length() > 80) { error("Enter a valid patient name."); return; }
                            try {
                                JSONObject newProfile = new JSONObject();
                                newProfile.put("name", value);
                                newProfile.put("id", "p" + UUID.randomUUID().toString().replace("-", ""));
                                profiles.put(newProfile);
                                getPreferences(MODE_PRIVATE).edit().putString("profiles", profiles.toString()).apply();
                                switchProfile(newProfile.getString("id"));
                            } catch (Exception e) { error("Couldn't add profile: " + e.getMessage()); }
                        }).show();
            }
        }).setNegativeButton("Close", null).show();
    }

    private void documentPicker(String action, String mimeType, String filename, int request) {
        Intent intent = new Intent(action);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        if (filename != null) intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(intent, request);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (request == EXPORT_CSV || request == BACKUP_JSON) {
                String value = request == EXPORT_CSV ? db.exportCsv() : db.exportBackup();
                if (request == BACKUP_JSON) {
                    JSONObject backup = new JSONObject(value);
                    backup.put("patient", profileLabel());
                    value = backup.toString(2);
                }
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Cannot create file");
                    out.write(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                message("File saved", request == BACKUP_JSON
                        ? "This JSON backup contains the current patient's medicine data. Keep it safe."
                        : "Open the CSV file in Excel or Google Sheets.");
            } else if (request == IMPORT_CSV || request == RESTORE_JSON) {
                String content;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Cannot read selected file");
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int count;
                    while ((count = in.read(buf)) != -1) {
                        bytes.write(buf, 0, count);
                        if (bytes.size() > 20_000_000) throw new IOException("File exceeds 20 MB");
                    }
                    content = bytes.toString("UTF-8");
                }
                String preview;
                if (request == RESTORE_JSON) {
                    // Validate BEFORE offering a replacement, not only after confirmation.
                    JSONObject header = new JSONObject(content);
                    preview = "Patient in backup: " + header.optString("patient", "Not specified")
                            + "\n" + db.backupPreview(content)
                            + "\nThe current patient's medicines, visit date and stock history will be replaced. Back up existing records first.";
                } else {
                    preview = "Importing CSV replaces the current patient's medicine list. Back up the inventory before continuing.";
                }
                new AlertDialog.Builder(this)
                        .setTitle(request == RESTORE_JSON ? "Preview JSON restore" : "Import Excel CSV?")
                        .setMessage(preview)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Replace data", (d, w) -> {
                            try {
                                if (request == RESTORE_JSON) db.restoreBackup(content);
                                else db.importCsv(content);
                                db.reconcile(); latestStockMessage = ""; expandedMedicines.clear(); draw();
                                message("Import complete", "The current patient's data has been updated.");
                            } catch (Exception e) { error("Could not import file: " + e.getMessage()); }
                        }).show();
            }
        } catch (Exception e) { error("File operation failed: " + e.getMessage()); }
    }

    private void message(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body)
                .setPositiveButton("OK", null).show();
    }
    private void error(String value) { message("Please check", value); }
}
