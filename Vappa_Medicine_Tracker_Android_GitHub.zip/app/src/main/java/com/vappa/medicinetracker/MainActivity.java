package com.vappa.medicinetracker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
  private MedicineDb db; private LinearLayout root,items; private TextView summary,visitText; private final int teal=Color.rgb(14,112,119),ink=Color.rgb(32,48,57),muted=Color.rgb(100,117,125),red=Color.rgb(174,48,48);
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(teal);getWindow().setNavigationBarColor(Color.rgb(245,248,249));db=new MedicineDb(this);db.reconcile();DailyReceiver.schedule(this);DailyReceiver.notifyLow(this,db);if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);draw();}
  @Override protected void onResume(){super.onResume();if(db!=null){db.reconcile();if(root!=null)draw();DailyReceiver.notifyLow(this,db);}}
  @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
  private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+0.5f);}
  private GradientDrawable bg(int fill,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));return d;}
  private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
  private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private void pad(View v,int p){v.setPadding(dp(p),dp(p),dp(p),dp(p));}
  private void space(LinearLayout l,int h){View x=new View(this);l.addView(x,new LinearLayout.LayoutParams(1,dp(h)));}
  private TextView button(String name,Runnable action){TextView t=label(name,14,Color.WHITE,true);t.setGravity(Gravity.CENTER);pad(t,12);t.setBackground(bg(teal,12));t.setOnClickListener(v->action.run());return t;}
  private String fmt(double x){if(Math.abs(x-Math.rint(x))<0.00001)return String.format(Locale.US,"%.0f",x);return String.format(Locale.US,"%.2f",x).replaceAll("0+$","").replaceAll("\\.$","");}
  private void draw(){
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(245,248,249));root=column();pad(root,16);scroll.addView(root);setContentView(scroll);
    TextView title=label("Vappa Medicine Tracker",24,teal,true);root.addView(title);space(root,4);root.addView(label("Personal medicine stock • Works offline",13,muted,false));space(root,18);
    LinearLayout visit=row();pad(visit,15);visit.setBackground(bg(Color.WHITE,16));LinearLayout info=column();visitText=label("Next visit: "+getVisitLabel(),16,ink,true);info.addView(visitText);info.addView(label(db.daysToVisit()+" day(s) remaining • Tap to change",12,muted,false));visit.addView(info,new LinearLayout.LayoutParams(0,-2,1));visit.addView(label("✎",22,teal,true));visit.setOnClickListener(v->dateDialog());root.addView(visit);space(root,12);
    LinearLayout stats=column();pad(stats,16);stats.setBackground(bg(Color.rgb(226,244,242),16));summary=label("",15,ink,true);stats.addView(summary);root.addView(stats);space(root,12);
    LinearLayout actions=row();TextView stock=button("+ Stock",()->stockDialog());actions.addView(stock,new LinearLayout.LayoutParams(0,dp(50),1));TextView add=button("+ Medicine",()->editDialog(null));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(50),1);ap.leftMargin=dp(8);actions.addView(add,ap);root.addView(actions);space(root,10);
    LinearLayout second=row();TextView purchase=button("Purchase list",()->purchaseDialog());second.addView(purchase,new LinearLayout.LayoutParams(0,dp(45),1));TextView history=button("Stock history",()->historyDialog());LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,dp(45),1);hp.leftMargin=dp(8);second.addView(history,hp);root.addView(second);space(root,20);
    root.addView(label("MY MEDICINES",13,muted,true));space(root,8);items=column();root.addView(items);refreshCards();space(root,16);root.addView(label("Stock decreases once per elapsed day, at the daily requirement. Box 1 is used first, then backup. Records can be corrected manually if actual consumption differs.",12,muted,false));
  }
  private String getVisitLabel(){try{return LocalDate.parse(db.getVisit()).format(DateTimeFormatter.ofPattern("d MMM yyyy",Locale.ENGLISH));}catch(Exception e){return db.getVisit();}}
  private void refreshCards(){items.removeAllViews();int alert=0,needed=0;long days=db.daysToVisit();List<MedicineDb.Medicine> meds=db.all();for(MedicineDb.Medicine m:meds){if(m.daily>0&&m.daysLeft()<=7)alert++;if(m.daily*days>m.total()+0.00001)needed++;medicineCard(m);}summary.setText(meds.size()+" medicines     •     "+alert+" low stock     •     "+needed+" need purchase");}
  private void medicineCard(MedicineDb.Medicine m){
    LinearLayout card=column();pad(card,15);card.setBackground(bg(Color.WHITE,15));LinearLayout line=row();TextView name=label(m.name,17,ink,true);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));String status=m.daily<=0?"NOT SCHEDULED":m.daysLeft()<=7?"REORDER":"IN STOCK";int c=m.daily>0&&m.daysLeft()<=7?red:teal;line.addView(label(status,11,c,true));card.addView(line);space(card,10);
    card.addView(label("Box 1: "+fmt(m.b1)+"    •    Backup: "+fmt(m.b2)+"    •    Total: "+fmt(m.total()),14,ink,false));space(card,5);
    card.addView(label("Daily: "+fmt(m.daily)+"    •    Stock lasts: "+(m.daily<=0?"Not applicable":fmt(m.daysLeft())+" days"),13,muted,false));
    double buy=Math.max(0,m.daily*db.daysToVisit()-m.total());space(card,5);card.addView(label("Needed until visit: "+fmt(m.daily*db.daysToVisit())+"   •   Buy: "+fmt(Math.ceil(buy-0.0000001)),13,buy>0?red:teal,true));
    card.setOnClickListener(v->editDialog(m));items.addView(card);space(items,9);
  }
  private void dateDialog(){LocalDate d;try{d=LocalDate.parse(db.getVisit());}catch(Exception e){d=LocalDate.now().plusMonths(1);}DatePickerDialog dlg=new DatePickerDialog(this,(picker,y,m,day)->{db.setVisit(LocalDate.of(y,m+1,day).toString());draw();},d.getYear(),d.getMonthValue()-1,d.getDayOfMonth());dlg.setTitle("Next hospital visit");dlg.show();}
  private EditText field(String hint,String initial,boolean number){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);e.setText(initial);if(number)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);return e;}
  private void addField(LinearLayout p,String title,EditText e){p.addView(label(title,13,muted,true));p.addView(e);space(p,7);}
  private Double parseNonnegative(EditText e){try{double n=Double.parseDouble(e.getText().toString().trim());return Double.isFinite(n)&&n>=0?n:null;}catch(Exception ex){return null;}}
  private void error(String msg){new AlertDialog.Builder(this).setTitle("Please check").setMessage(msg).setPositiveButton("OK",null).show();}
  private void editDialog(MedicineDb.Medicine m){
    boolean existing=m!=null;LinearLayout form=column();pad(form,18);EditText name=field("Medicine name",existing?m.name:"",false);EditText daily=field("Daily requirement",existing?fmt(m.daily):"1",true);EditText b1=field("Box 1 tablets",existing?fmt(m.b1):"0",true);EditText b2=field("Backup tablets",existing?fmt(m.b2):"0",true);
    addField(form,"Medicine name",name);addField(form,"Tablets per day (fractional values allowed)",daily);addField(form,"Current use — Box 1",b1);addField(form,"Backup — Box 2",b2);
    AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(existing?"Edit medicine":"Add medicine").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null);
    if(existing)builder.setNeutralButton("Delete",(dialog,which)->new AlertDialog.Builder(this).setTitle("Delete "+m.name+"?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.delete(m.id);draw();DailyReceiver.notifyLow(this,db);}).show());
    AlertDialog dialog=builder.create();dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{String n=name.getText().toString().trim();Double d=parseNonnegative(daily),x=parseNonnegative(b1),y=parseNonnegative(b2);if(n.isEmpty()||d==null||x==null||y==null){error("Enter a medicine name and valid non-negative quantities.");return;}db.upsert(existing?m.id:null,n,d,x,y);dialog.dismiss();draw();DailyReceiver.notifyLow(this,db);}));dialog.show();
  }
  private void stockDialog(){
    List<MedicineDb.Medicine> meds=db.all();if(meds.isEmpty()){error("Add a medicine first.");return;}String[] names=new String[meds.size()];for(int i=0;i<names.length;i++)names[i]=meds.get(i).name;
    LinearLayout form=column();pad(form,18);Spinner med=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);med.setAdapter(adapter);form.addView(label("Medicine",13,muted,true));form.addView(med);space(form,8);
    Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Purchase new stock","Transfer backup → Box 1"}));form.addView(label("Action",13,muted,true));form.addView(type);space(form,8);
    EditText amount=field("Quantity", "",true);addField(form,"Quantity (tablets)",amount);
    Spinner dest=new Spinner(this);dest.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Box 1 (current use)","Box 2 (backup)"}));form.addView(label("Purchase destination",13,muted,true));form.addView(dest);type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){dest.setVisibility(pos==0?View.VISIBLE:View.GONE);}public void onNothingSelected(android.widget.AdapterView<?> p){}});
    AlertDialog dlg=new AlertDialog.Builder(this).setTitle("+ Add / Transfer Stock").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dlg.setOnShowListener(v->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{Double qty=parseNonnegative(amount);if(qty==null||qty<=0){error("Enter a quantity greater than zero.");return;}MedicineDb.Medicine m=meds.get(med.getSelectedItemPosition());boolean transfer=type.getSelectedItemPosition()==1;boolean toBackup=dest.getSelectedItemPosition()==1;String result=db.stockAction(m.id,transfer,toBackup,qty);if(result!=null){error(result);return;}dlg.dismiss();draw();DailyReceiver.notifyLow(this,db);}));dlg.show();
  }
  private void purchaseDialog(){StringBuilder b=new StringBuilder();long days=db.daysToVisit();for(MedicineDb.Medicine m:db.all()){double n=Math.max(0,m.daily*days-m.total());if(n>0.000001)b.append(m.name).append(": ").append(fmt(Math.ceil(n-0.000001))).append(" tablet(s)\n");}new AlertDialog.Builder(this).setTitle("To purchase until "+getVisitLabel()).setMessage(b.length()==0?"All medicines have enough stock for the next visit.":b.toString().trim()).setPositiveButton("Done",null).show();}
  private void historyDialog(){List<String> records=db.history();String s=records.isEmpty()?"No purchases or transfers recorded yet.":String.join("\n\n",records);new AlertDialog.Builder(this).setTitle("Stock history (latest 100)").setMessage(s).setPositiveButton("Close",null).show();}
}
