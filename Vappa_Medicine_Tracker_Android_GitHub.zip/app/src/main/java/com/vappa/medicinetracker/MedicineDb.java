package com.vappa.medicinetracker;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class MedicineDb extends SQLiteOpenHelper {
  static final String DB_NAME="vappa_medicines.db";
  public MedicineDb(Context c){super(c,DB_NAME,null,1);}
  @Override public void onCreate(SQLiteDatabase db){
    db.execSQL("CREATE TABLE medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL, daily REAL NOT NULL, box1 REAL NOT NULL, box2 REAL NOT NULL, last_date TEXT NOT NULL)");
    db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, val TEXT NOT NULL)");
    db.execSQL("CREATE TABLE stock_log(id INTEGER PRIMARY KEY AUTOINCREMENT,medicine TEXT NOT NULL,kind TEXT NOT NULL,qty REAL NOT NULL,destination TEXT NOT NULL,created TEXT NOT NULL)");
    db.execSQL("INSERT INTO settings(key,val) VALUES('visit','2026-12-03')");
    String today=LocalDate.now().toString();
    seed(db,"Pantoprazole",1,22,0,today);
    seed(db,"Ticagrelor",2,8,0,today);
    seed(db,"Nebivolol",0.7,9,0,today);
    seed(db,"Empagliflozin",1,2,0,today);
    seed(db,"Aldactone",0.7,16,15,today);
    seed(db,"Aspirin",1,16,44,today);
    seed(db,"Ramipril",1,4,0,today);
    seed(db,"Rosuvastatin",1,14,20,today);
    seed(db,"Bisoprolol",0,0,25,today);
  }
  private static void seed(SQLiteDatabase db,String name,double daily,double b1,double b2,String day){ContentValues c=new ContentValues();c.put("name",name);c.put("daily",daily);c.put("box1",b1);c.put("box2",b2);c.put("last_date",day);db.insert("medicines",null,c);}
  @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
  public static class Medicine {
    public long id; public String name; public double daily,b1,b2; public String lastDate;
    public double total(){return b1+b2;}
    public double daysLeft(){return daily<=0?Double.POSITIVE_INFINITY:total()/daily;}
  }
  public synchronized List<Medicine> all(){List<Medicine> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,daily,box1,box2,last_date FROM medicines ORDER BY name COLLATE NOCASE",null)){while(c.moveToNext()){Medicine m=new Medicine();m.id=c.getLong(0);m.name=c.getString(1);m.daily=c.getDouble(2);m.b1=c.getDouble(3);m.b2=c.getDouble(4);m.lastDate=c.getString(5);out.add(m);}}return out;}
  public synchronized void upsert(Long id,String name,double daily,double b1,double b2){
    reconcile(); ContentValues v=new ContentValues();v.put("name",name);v.put("daily",daily);v.put("box1",b1);v.put("box2",b2);v.put("last_date",LocalDate.now().toString());
    if(id==null)getWritableDatabase().insertOrThrow("medicines",null,v); else getWritableDatabase().update("medicines",v,"id=?",new String[]{String.valueOf(id)});
  }
  public synchronized String stockAction(long id,boolean transfer,boolean toBackup,double amount){
    if(!Double.isFinite(amount)||amount<=0)return "Enter a positive quantity.";
    reconcile();SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
    try(Cursor c=db.rawQuery("SELECT name,box1,box2 FROM medicines WHERE id=?",new String[]{String.valueOf(id)})){
      if(!c.moveToFirst())return "Medicine not found.";
      String name=c.getString(0);double b1=c.getDouble(1),b2=c.getDouble(2);
      if(transfer){if(amount>b2+0.000001)return "Backup stock is insufficient. Available: "+b2;b1+=amount;b2-=amount;}
      else if(toBackup)b2+=amount;else b1+=amount;
      ContentValues v=new ContentValues();v.put("box1",clean(b1));v.put("box2",clean(b2));db.update("medicines",v,"id=?",new String[]{String.valueOf(id)});
      ContentValues log=new ContentValues();log.put("medicine",name);log.put("kind",transfer?"Transfer":"Purchase");log.put("qty",amount);log.put("destination",transfer?"Backup to Box 1":(toBackup?"Backup":"Box 1"));log.put("created",java.time.LocalDateTime.now().toString());db.insert("stock_log",null,log);
      db.setTransactionSuccessful();return null;
    }finally{db.endTransaction();}
  }
  public synchronized java.util.List<String> history(){java.util.List<String> out=new java.util.ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT created,medicine,kind,qty,destination FROM stock_log ORDER BY id DESC LIMIT 100",null)){while(c.moveToNext()){String date=c.getString(0).replace('T',' ');if(date.length()>16)date=date.substring(0,16);out.add(date+" • "+c.getString(1)+"\n"+c.getString(2)+" "+c.getDouble(3)+" tablet(s) • "+c.getString(4));}}return out;}
  public synchronized void delete(long id){getWritableDatabase().delete("medicines","id=?",new String[]{String.valueOf(id)});}
  public synchronized String getVisit(){try(Cursor c=getReadableDatabase().rawQuery("SELECT val FROM settings WHERE key='visit'",null)){return c.moveToFirst()?c.getString(0):LocalDate.now().plusDays(30).toString();}}
  public synchronized void setVisit(String visit){ContentValues v=new ContentValues();v.put("key","visit");v.put("val",visit);getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
  public long daysToVisit(){try{return Math.max(0,ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(getVisit())));}catch(Exception e){return 0;}}
  // Date-based reconciliation is idempotent: deduct once for every elapsed local calendar day.
  // The saved starting date represents stock on the installation/edit date. Never go negative.
  public synchronized void reconcile(){
    SQLiteDatabase db=getWritableDatabase();String today=LocalDate.now().toString();db.beginTransaction();
    try(Cursor c=db.rawQuery("SELECT id,daily,box1,box2,last_date FROM medicines",null)){
      while(c.moveToNext()){
        long id=c.getLong(0);double daily=c.getDouble(1),b1=c.getDouble(2),b2=c.getDouble(3);String last=c.getString(4);long n=0;
        try{n=ChronoUnit.DAYS.between(LocalDate.parse(last),LocalDate.parse(today));}catch(Exception ignored){}
        if(n<=0)continue;
        double use=daily*n;double consumed1=Math.min(Math.max(0,b1),use);b1=Math.max(0,b1-consumed1);use-=consumed1;b2=Math.max(0,b2-use);
        ContentValues v=new ContentValues();v.put("box1",clean(b1));v.put("box2",clean(b2));v.put("last_date",today);db.update("medicines",v,"id=?",new String[]{String.valueOf(id)});
      }
      db.setTransactionSuccessful();
    }finally{db.endTransaction();}
  }
  public static double clean(double n){return Math.round(Math.max(0,n)*1000d)/1000d;}
  public int lowCount(){int n=0;for(Medicine m:all())if(m.daily>0 && m.daysLeft()<=7)n++;return n;}
}
