package com.vappa.medicinetracker;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class MedicineDb extends SQLiteOpenHelper {
  static final String DB_NAME="vappa_medicines.db";
  public MedicineDb(Context c){this(c,"default");}
  public MedicineDb(Context c,String profile){super(c,"default".equals(profile)?DB_NAME:"vappa_medicines_"+profile.replaceAll("[^a-zA-Z0-9_-]", "_")+".db",null,2);}
  @Override public void onCreate(SQLiteDatabase db){
    db.execSQL("CREATE TABLE medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL, daily REAL NOT NULL, box1 REAL NOT NULL, box2 REAL NOT NULL, last_date TEXT NOT NULL, photo TEXT DEFAULT '')");
    db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, val TEXT NOT NULL)");
    db.execSQL("CREATE TABLE stock_log(id INTEGER PRIMARY KEY AUTOINCREMENT,medicine TEXT NOT NULL,kind TEXT NOT NULL,qty REAL NOT NULL,destination TEXT NOT NULL,created TEXT NOT NULL)");
    

  }
  private static void seed(SQLiteDatabase db,String name,double daily,double b1,double b2,String day){ContentValues c=new ContentValues();c.put("name",name);c.put("daily",daily);c.put("box1",b1);c.put("box2",b2);c.put("last_date",day);db.insert("medicines",null,c);}
  @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
    if(oldVersion<2){db.execSQL("ALTER TABLE medicines ADD COLUMN photo TEXT DEFAULT ''");}
  }
  public static class Medicine {
    public long id; public String name; public double daily,b1,b2; public String lastDate,photo="";
    public double total(){return b1+b2;}
    public double daysLeft(){return daily<=0?Double.POSITIVE_INFINITY:total()/daily;}
  }
  public synchronized List<Medicine> all(){List<Medicine> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,daily,box1,box2,last_date,photo FROM medicines ORDER BY name COLLATE NOCASE",null)){while(c.moveToNext()){Medicine m=new Medicine();m.id=c.getLong(0);m.name=c.getString(1);m.daily=c.getDouble(2);m.b1=c.getDouble(3);m.b2=c.getDouble(4);m.lastDate=c.getString(5);m.photo=c.getString(6);out.add(m);}}return out;}
  public synchronized void upsert(Long id,String name,double daily,double b1,double b2){
    reconcile(); ContentValues v=new ContentValues();v.put("name",name);v.put("daily",daily);v.put("box1",b1);v.put("box2",b2);v.put("last_date",LocalDate.now().toString());
    if(id==null)getWritableDatabase().insertOrThrow("medicines",null,v); else getWritableDatabase().update("medicines",v,"id=?",new String[]{String.valueOf(id)});
  }
  public synchronized String stockAction(long id,boolean transfer,boolean toBackup,double amount){
    if(!Double.isFinite(amount)||amount<=0)return "Enter a positive quantity.";
    reconcile();SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
    try(Cursor c=db.rawQuery("SELECT name,box1,box2 FROM medicines WHERE id=?",new String[]{String.valueOf(id)})){
      if(!c.moveToFirst())return "Medicine not found.";
      String name=c.getString(0);double b1=c.getDouble(1),b2=c.getDouble(2);
      if(transfer){if(amount>b2+0.000001)return "Backup stock is insufficient. Available: "+b2;b1+=amount;b2-=amount;}
      else if(toBackup)b2+=amount;else b1+=amount;
      ContentValues v=new ContentValues();v.put("box1",clean(b1));v.put("box2",clean(b2));db.update("medicines",v,"id=?",new String[]{String.valueOf(id)});
      ContentValues log=new ContentValues();log.put("medicine",name);log.put("kind",transfer?"Transfer":"Purchase");log.put("qty",amount);log.put("destination",transfer?"Backup to Box 1":(toBackup?"Backup":"Box 1"));log.put("created",java.time.LocalDateTime.now().toString());db.insert("stock_log",null,log);
      db.setTransactionSuccessful();return null;
    }finally{db.endTransaction();}
  }
  public synchronized java.util.List<String> history(){java.util.List<String> out=new java.util.ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT created,medicine,kind,qty,destination FROM stock_log ORDER BY id DESC LIMIT 100",null)){while(c.moveToNext()){String date=c.getString(0).replace('T',' ');if(date.length()>16)date=date.substring(0,16);out.add(date+" • "+c.getString(1)+"\n"+c.getString(2)+" "+c.getDouble(3)+" tablet(s) • "+c.getString(4));}}return out;}
  public synchronized void clearInventory(){
    SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
    try{d.delete("medicines",null,null);d.delete("stock_log",null,null);d.setTransactionSuccessful();}
    finally{d.endTransaction();}
  }
  public synchronized void updatePhoto(long id,String path){ContentValues v=new ContentValues();v.put("photo",path);getWritableDatabase().update("medicines",v,"id=?",new String[]{String.valueOf(id)});}
  public synchronized Medicine find(long id){for(Medicine m:all())if(m.id==id)return m;return null;}
  public synchronized String undoLatest(){
    reconcile();SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
    try(Cursor c=d.rawQuery("SELECT id,medicine,kind,qty,destination FROM stock_log WHERE kind IN ('Purchase','Transfer') ORDER BY id DESC LIMIT 1",null)){
      if(!c.moveToFirst())return "No purchase or transfer to undo.";
      long logId=c.getLong(0);String name=c.getString(1),kind=c.getString(2),dest=c.getString(4);double amount=c.getDouble(3);
      try(Cursor mc=d.rawQuery("SELECT id,box1,box2 FROM medicines WHERE name=? COLLATE NOCASE ORDER BY id DESC LIMIT 1",new String[]{name})){
        if(!mc.moveToFirst())return "Medicine no longer exists; cannot safely undo.";
        long id=mc.getLong(0);double a=mc.getDouble(1),b=mc.getDouble(2);
        if("Transfer".equals(kind)){if(a+1e-8<amount)return "Box 1 has insufficient stock to undo this transfer.";a-=amount;b+=amount;}
        else if("Backup".equals(dest)){if(b+1e-8<amount)return "Backup has insufficient stock to undo this purchase.";b-=amount;}
        else {if(a+1e-8<amount)return "Box 1 has insufficient stock to undo this purchase.";a-=amount;}
        ContentValues v=new ContentValues();v.put("box1",clean(a));v.put("box2",clean(b));d.update("medicines",v,"id=?",new String[]{String.valueOf(id)});
        d.delete("stock_log","id=?",new String[]{String.valueOf(logId)});
        ContentValues audit=new ContentValues();audit.put("medicine",name);audit.put("kind","Undo "+kind);audit.put("qty",amount);audit.put("destination",dest);audit.put("created",LocalDateTime.now().toString());d.insert("stock_log",null,audit);
        d.setTransactionSuccessful();return null;
      }
    }finally{d.endTransaction();}
  }
  public synchronized void delete(long id){getWritableDatabase().delete("medicines","id=?",new String[]{String.valueOf(id)});}
  public synchronized String getVisit(){try(Cursor c=getReadableDatabase().rawQuery("SELECT val FROM settings WHERE key='visit'",null)){return c.moveToFirst()?c.getString(0):"";}}
  public synchronized void setVisit(String visit){ContentValues v=new ContentValues();v.put("key","visit");v.put("val",visit);getWritableDatabase().insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
  public long daysToVisit(){try{return Math.max(0,ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(getVisit())));}catch(Exception e){return 0;}}
  // Date-based reconciliation is idempotent: deduct once for every elapsed local calendar day.
  // The saved starting date represents stock on the installation/edit date. Never go negative.
  public synchronized void reconcile(){
    SQLiteDatabase db=getWritableDatabase();String today=LocalDate.now().toString();db.beginTransaction();
    try(Cursor c=db.rawQuery("SELECT id,daily,box1,box2,last_date FROM medicines",null)){
      while(c.moveToNext()){
        long id=c.getLong(0);double daily=c.getDouble(1),b1=c.getDouble(2),b2=c.getDouble(3);String last=c.getString(4);long n=0;
        try{n=ChronoUnit.DAYS.between(LocalDate.parse(last),LocalDate.parse(today));}catch(Exception ignored){}
        if(n<=0)continue;
        double use=daily*n;double consumed1=Math.min(Math.max(0,b1),use);b1=Math.max(0,b1-consumed1);use-=consumed1;b2=Math.max(0,b2-use);
        ContentValues v=new ContentValues();v.put("box1",clean(b1));v.put("box2",clean(b2));v.put("last_date",today);db.update("medicines",v,"id=?",new String[]{String.valueOf(id)});
      }
      db.setTransactionSuccessful();
    }finally{db.endTransaction();}
  }
  public static double clean(double n){return Math.round(Math.max(0,n)*1000d)/1000d;}
  public int lowCount(){int n=0;for(Medicine m:all())if(m.daily>0 && m.daysLeft()<=7)n++;return n;}
  private static String csvQuote(String v){return "\""+v.replace("\"","\"\"")+"\"";}
  public synchronized String exportCsv(){
    reconcile();StringBuilder s=new StringBuilder("Medicine,Daily requirement,Box 1,Backup box\r\n");
    for(Medicine m:all())s.append(csvQuote(m.name)).append(',').append(m.daily).append(',').append(m.b1).append(',').append(m.b2).append("\r\n");return s.toString();
  }
  private static java.util.List<String> csvLine(String line){
    java.util.List<String> fields=new ArrayList<>();StringBuilder b=new StringBuilder();boolean quoted=false;
    for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){b.append('"');i++;}else quoted=!quoted;}else if(ch==','&&!quoted){fields.add(b.toString());b.setLength(0);}else b.append(ch);}if(quoted)throw new IllegalArgumentException("Unclosed quoted CSV field");fields.add(b.toString());return fields;
  }
  public synchronized void importCsv(String input){
    String[] lines=input.replace("\uFEFF","").split("\\r?\\n");if(lines.length<2)throw new IllegalArgumentException("No medicine rows found");
    java.util.List<String> header=csvLine(lines[0]);if(header.size()<4||!header.get(0).trim().equalsIgnoreCase("Medicine"))throw new IllegalArgumentException("Expected columns: Medicine,Daily requirement,Box 1,Backup box");
    java.util.List<Medicine> entries=new ArrayList<>();
    for(int i=1;i<lines.length;i++){if(lines[i].trim().isEmpty())continue;java.util.List<String> f=csvLine(lines[i]);if(f.size()<4)throw new IllegalArgumentException("Incomplete row "+(i+1));Medicine m=new Medicine();m.name=f.get(0).trim();if(m.name.isEmpty())throw new IllegalArgumentException("Empty medicine on row "+(i+1));try{m.daily=Double.parseDouble(f.get(1).trim());m.b1=Double.parseDouble(f.get(2).trim());m.b2=Double.parseDouble(f.get(3).trim());}catch(NumberFormatException e){throw new IllegalArgumentException("Invalid quantity on row "+(i+1));}if(!valid(m.daily)||!valid(m.b1)||!valid(m.b2))throw new IllegalArgumentException("Invalid quantity on row "+(i+1));entries.add(m);}
    if(entries.isEmpty())throw new IllegalArgumentException("No medicine rows found");if(entries.size()>1000)throw new IllegalArgumentException("Too many medicines");
    reconcile();SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{d.delete("medicines",null,null);String today=LocalDate.now().toString();for(Medicine m:entries)seed(d,m.name,m.daily,m.b1,m.b2,today);d.setTransactionSuccessful();}finally{d.endTransaction();}
  }
  public synchronized String backupPreview(String json) throws org.json.JSONException {
    org.json.JSONObject o=new org.json.JSONObject(json);
    if(!"vappa-medicine-backup-v1".equals(o.optString("format")))throw new IllegalArgumentException("Unrecognized backup format");
    String visit=o.getString("visit");if(!visit.isEmpty())LocalDate.parse(visit);
    org.json.JSONArray meds=o.getJSONArray("medicines");if(meds.length()>1000)throw new IllegalArgumentException("Too many medicines");
    StringBuilder b=new StringBuilder("Next visit: "+(visit.isEmpty()?"Not set":visit)+"\nMedicines: "+meds.length()+"\nHistory entries: "+(o.optJSONArray("stock_history")==null?0:o.getJSONArray("stock_history").length())+"\n\n");
    for(int i=0;i<Math.min(15,meds.length());i++){org.json.JSONObject m=meds.getJSONObject(i);b.append(m.getString("name")).append(" — daily ").append(m.getDouble("daily")).append(", Box 1 ").append(m.getDouble("box1")).append(", backup ").append(m.getDouble("box2")).append("\n");}
    if(meds.length()>15)b.append("... and ").append(meds.length()-15).append(" more\n");
    return b.toString();
  }
  private static boolean valid(double v){return Double.isFinite(v)&&v>=0&&v<=100000000;}
  public synchronized String exportBackup() throws org.json.JSONException {
    reconcile();org.json.JSONObject root=new org.json.JSONObject();root.put("format","vappa-medicine-backup-v1");root.put("visit",getVisit());org.json.JSONArray meds=new org.json.JSONArray();for(Medicine m:all()){org.json.JSONObject o=new org.json.JSONObject();o.put("name",m.name);o.put("daily",m.daily);o.put("box1",m.b1);o.put("box2",m.b2);o.put("last_date",m.lastDate);o.put("photo",m.photo==null?"":m.photo);meds.put(o);}root.put("medicines",meds);
    org.json.JSONArray history=new org.json.JSONArray();try(Cursor c=getReadableDatabase().rawQuery("SELECT medicine,kind,qty,destination,created FROM stock_log ORDER BY id",null)){while(c.moveToNext()){org.json.JSONObject o=new org.json.JSONObject();o.put("medicine",c.getString(0));o.put("kind",c.getString(1));o.put("qty",c.getDouble(2));o.put("destination",c.getString(3));o.put("created",c.getString(4));history.put(o);}}root.put("stock_history",history);return root.toString(2);
  }
  public synchronized void restoreBackup(String json) throws org.json.JSONException {
    org.json.JSONObject root=new org.json.JSONObject(json);if(!"vappa-medicine-backup-v1".equals(root.optString("format")))throw new IllegalArgumentException("Not a Vappa Medicine backup");String visit=root.getString("visit");if(!visit.isEmpty())LocalDate.parse(visit);org.json.JSONArray meds=root.getJSONArray("medicines"),logs=root.optJSONArray("stock_history");if(meds.length()>1000||logs!=null&&logs.length()>100000)throw new IllegalArgumentException("Backup too large");
    java.util.List<Medicine> parsed=new ArrayList<>();for(int i=0;i<meds.length();i++){org.json.JSONObject o=meds.getJSONObject(i);Medicine m=new Medicine();m.name=o.getString("name").trim();m.daily=o.getDouble("daily");m.b1=o.getDouble("box1");m.b2=o.getDouble("box2");m.lastDate=o.getString("last_date");m.photo=o.optString("photo","");if(m.photo.length()>1300000)throw new IllegalArgumentException("Photo too large in backup");LocalDate.parse(m.lastDate);if(m.name.isEmpty()||m.name.length()>200||!valid(m.daily)||!valid(m.b1)||!valid(m.b2))throw new IllegalArgumentException("Invalid backup medicine");parsed.add(m);}
    if(logs!=null)for(int i=0;i<logs.length();i++){
      org.json.JSONObject o=logs.getJSONObject(i);if(o.getString("medicine").length()>200||o.getString("kind").length()>60||o.getString("destination").length()>150||o.getString("created").length()>60||!valid(o.getDouble("qty")))throw new IllegalArgumentException("Invalid history record "+(i+1));
    }
    SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{d.delete("medicines",null,null);d.delete("stock_log",null,null);for(Medicine m:parsed){ContentValues v=new ContentValues();v.put("name",m.name);v.put("daily",m.daily);v.put("box1",m.b1);v.put("box2",m.b2);v.put("last_date",m.lastDate);v.put("photo",m.photo);d.insertOrThrow("medicines",null,v);}ContentValues visitVal=new ContentValues();visitVal.put("key","visit");visitVal.put("val",visit);d.insertWithOnConflict("settings",null,visitVal,SQLiteDatabase.CONFLICT_REPLACE);if(logs!=null)for(int i=0;i<logs.length();i++){org.json.JSONObject o=logs.getJSONObject(i);ContentValues v=new ContentValues();v.put("medicine",o.getString("medicine"));v.put("kind",o.getString("kind"));v.put("qty",o.getDouble("qty"));v.put("destination",o.getString("destination"));v.put("created",o.getString("created"));d.insertOrThrow("stock_log",null,v);}d.setTransactionSuccessful();}finally{d.endTransaction();}
  }
}
